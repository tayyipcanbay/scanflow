# FitScan3D - AI Body Transformation Tracker

A comprehensive 3D body scan comparison platform that helps users track fitness progress through mesh analysis and AI-powered recommendations.

## Features

### 🎯 Core Functionality

- **3D Body Scanning**: Upload and store OBJ, GLB, and FBX mesh files from body scanners
- **Visual Comparison**: Interactive 3D visualization with color-coded body regions
  - 🔴 Red = Muscle gain (volume increase)
  - 🔵 Blue/Green = Fat loss (volume decrease)
  - ⚪ White = No significant change
- **Body Composition Analysis**: Accurate body fat percentage and muscle mass calculations
- **Region Detection**: Automatic identification of body regions (waist, chest, arms, thighs, hips, shoulders, calves)

### 🤖 AI-Powered Features

- **Personalized Meal Plans**: Weekly meal plans tailored to your body composition and fitness goals (bulking, cutting, maintaining, recomp)
- **Smart Exercise Recommendations**: Targeted workouts based on your body scan analysis
- **AI Fitness Coach**: Chat with an AI that understands your progress and provides personalized guidance
- **Injury Awareness**: AI adapts recommendations to avoid exercises that may aggravate reported injuries or pain

### 📊 Progress Tracking

- **Scan Timeline**: View all your scans chronologically
- **Comparison History**: Track changes between any two scans
- **Body Metrics Dashboard**: Monitor body fat %, muscle mass changes, and regional improvements
- **Progress Charts**: Visualize your transformation over time

## Getting Started

### Prerequisites

- Node.js 22+ installed
- A 3D body scan from a compatible scanner (many gyms and fitness centers offer this service)
- Supported file formats: OBJ, GLB, FBX

### Installation

1. Clone the repository:
   ```bash
   git clone <your-repo-url>
   cd fitscan3d
   ```

2. Install dependencies:
   ```bash
   pnpm install
   ```

3. Set up environment variables (automatically configured in Manus):
   - Database connection
   - S3 storage credentials
   - OpenAI API key (for AI features)

4. Push database schema:
   ```bash
   pnpm db:push
   ```

5. Start the development server:
   ```bash
   pnpm dev
   ```

6. Open your browser to `http://localhost:3000`

### Deployment

This app is designed to deploy seamlessly on Manus platform:

1. Create a checkpoint from the Manus UI
2. Click the "Publish" button
3. Your app will be live with custom domain support

For other platforms (Vercel, Railway, etc.), note that compatibility may vary.

## Usage Guide

### 1. Set Up Your Profile

After signing in, complete your profile with:
- Height and weight
- Age and gender
- Fitness goal (bulking, cutting, maintaining, or recomp)
- Activity level

### 2. Upload Your Baseline Scan

1. Get a 3D body scan from a compatible scanner
2. Navigate to "Upload Scan" from the dashboard
3. Drag and drop your mesh file (OBJ, GLB, or FBX)
4. Add scan date and any notes

### 3. Follow Your AI Plan

- Generate a personalized meal plan based on your profile
- Get exercise recommendations targeting specific body regions
- Chat with the AI coach for guidance and motivation

### 4. Track Your Progress

- Upload new scans every 4-8 weeks
- Create comparisons to see color-coded visualizations
- Review body metrics and adjust your plan accordingly

### 5. Optimize and Repeat

- AI automatically adjusts recommendations based on your progress
- Update your profile as your goals change
- Keep improving with data-driven insights

## Color Coding Explained

The 3D visualization uses a color-coded system to show body changes:

- **Red regions**: Volume increase, typically indicating muscle gain
- **Blue/Green regions**: Volume decrease, typically indicating fat loss
- **White regions**: No significant change

The intensity of the color indicates the magnitude of change. Darker colors mean larger changes.

## Technology Stack

### Frontend
- React 19 with TypeScript
- Three.js for 3D visualization
- @react-three/fiber and @react-three/drei for React integration
- Tailwind CSS 4 for styling
- shadcn/ui components
- tRPC for type-safe API calls

### Backend
- Express 4 server
- tRPC 11 for API layer
- Drizzle ORM with MySQL/TiDB
- OpenAI API for AI features
- S3 for file storage

### Key Libraries
- **Mesh Processing**: Custom OBJ parser with volume/surface area calculations
- **Body Analysis**: Anthropometric algorithms for body composition
- **AI Integration**: OpenAI GPT for meal plans, exercises, and chat

## API Documentation

### Profile Management

```typescript
// Get user profile
trpc.profile.get.useQuery()

// Update profile
trpc.profile.update.useMutation({
  height: 180,
  weight: 75,
  age: 30,
  gender: "male",
  fitnessGoal: "maintaining",
  activityLevel: "moderate"
})
```

### Scan Management

```typescript
// List all scans
trpc.scans.list.useQuery()

// Upload new scan
trpc.scans.upload.useMutation({
  fileName: "scan.obj",
  fileFormat: "obj",
  fileSize: 1024000,
  scanDate: new Date(),
  fileContent: base64String
})

// Get scan by ID
trpc.scans.getById.useQuery({ scanId: 1 })
```

### Comparisons

```typescript
// List all comparisons
trpc.comparisons.list.useQuery()

// Create comparison
trpc.comparisons.create.useMutation({
  baselineScanId: 1,
  comparisonScanId: 2
})

// Get comparison details
trpc.comparisons.getById.useQuery({ comparisonId: 1 })
```

### AI Features

```typescript
// Generate meal plan
trpc.ai.generateMealPlan.useMutation({
  comparisonId: 1 // optional
})

// Generate exercises
trpc.ai.generateExercises.useMutation({
  comparisonId: 1,
  injuries: ["knee pain"] // optional
})

// Chat with AI
trpc.ai.chat.useMutation({
  message: "What should I eat to build muscle?",
  injuries: ["knee pain"] // optional
})
```

## Database Schema

### Tables

- **users**: User authentication and basic info
- **user_profiles**: Height, weight, age, fitness goals
- **body_scans**: 3D mesh file references and metadata
- **scan_comparisons**: Pairs of scans with analysis results
- **body_region_metrics**: Detailed changes per body region
- **meal_plans**: AI-generated weekly meal plans
- **exercise_recommendations**: Targeted workout suggestions
- **chat_messages**: AI chatbot conversation history

## Testing

Run the test suite:

```bash
pnpm test
```

Tests cover:
- Profile management
- Mesh processing algorithms
- Body composition calculations
- API endpoints
- Authentication flows

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For questions or issues:
- Open an issue on GitHub
- Contact support at help@fitscan3d.com

## Acknowledgments

- Three.js community for 3D visualization tools
- OpenAI for AI capabilities
- Manus platform for hosting and infrastructure

---

**Transform your body with precision and AI-powered guidance. Start your journey today!**

import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Html } from '@react-three/drei';
import * as THREE from 'three';
import { Suspense, useEffect, useRef, useState } from 'react';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

interface MeshViewerProps {
  fileUrl?: string;
  fileFormat?: 'obj' | 'glb' | 'fbx';
  isAfterScan?: boolean;
  useDemo?: boolean; // Use demo GLB files from public folder
}

// GLB Model Loader component
function GLBModel({ url, isAfterScan }: { url: string, isAfterScan?: boolean }) {
  const groupRef = useRef<THREE.Group>(null);
  const [model, setModel] = useState<THREE.Group | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loader = new GLTFLoader();
    
    loader.load(
      url,
      (gltf) => {
        const loadedModel = gltf.scene.clone();
        
        // Center and scale the model
        const box = new THREE.Box3().setFromObject(loadedModel);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);
        const scale = 1.2 / maxDim;
        
        loadedModel.scale.setScalar(scale);
        loadedModel.position.sub(center.multiplyScalar(scale));
        
        // Apply color mapping for after scan to show changes
        if (isAfterScan) {
          loadedModel.traverse((child) => {
            if (child instanceof THREE.Mesh && child.geometry) {
              const geometry = child.geometry;
              const positionAttr = geometry.attributes.position;
              const vertexCount = positionAttr.count;
              
              // Create vertex colors based on body region (Y position)
              const colors = new Float32Array(vertexCount * 3);
              
              for (let i = 0; i < vertexCount; i++) {
                const y = positionAttr.getY(i);
                const normalizedY = (y + 1) / 2; // Normalize to 0-1
                
                // Color based on body region
                if (normalizedY > 0.75) {
                  // Head/neck - neutral
                  colors[i * 3] = 0.9;
                  colors[i * 3 + 1] = 0.75;
                  colors[i * 3 + 2] = 0.65;
                } else if (normalizedY > 0.55) {
                  // Chest/shoulders - red (muscle gain)
                  colors[i * 3] = 0.9;
                  colors[i * 3 + 1] = 0.3;
                  colors[i * 3 + 2] = 0.3;
                } else if (normalizedY > 0.4) {
                  // Waist - cyan (fat loss)
                  colors[i * 3] = 0.2;
                  colors[i * 3 + 1] = 0.8;
                  colors[i * 3 + 2] = 0.8;
                } else if (normalizedY > 0.2) {
                  // Thighs - purple
                  colors[i * 3] = 0.6;
                  colors[i * 3 + 1] = 0.3;
                  colors[i * 3 + 2] = 0.8;
                } else {
                  // Lower legs - neutral
                  colors[i * 3] = 0.9;
                  colors[i * 3 + 1] = 0.75;
                  colors[i * 3 + 2] = 0.65;
                }
              }
              
              geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
              
              // Create new material with vertex colors
              child.material = new THREE.MeshStandardMaterial({
                vertexColors: true,
                roughness: 0.7,
                metalness: 0.1,
              });
            }
          });
        } else {
          // Before scan - apply skin tone
          loadedModel.traverse((child) => {
            if (child instanceof THREE.Mesh) {
              child.material = new THREE.MeshStandardMaterial({
                color: new THREE.Color(0.85, 0.7, 0.6),
                roughness: 0.7,
                metalness: 0.1,
              });
            }
          });
        }
        
        setModel(loadedModel);
      },
      undefined,
      (err) => {
        console.error('Error loading GLB:', err);
        setError('Failed to load model');
      }
    );
  }, [url, isAfterScan]);

  // Rotate model slowly
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.3;
    }
  });

  if (error) {
    return (
      <Html center>
        <div className="text-red-400 bg-black/50 px-4 py-2 rounded text-sm">
          {error}
        </div>
      </Html>
    );
  }

  if (!model) {
    return (
      <Html center>
        <div className="flex flex-col items-center gap-2">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
          <span className="text-white text-sm">Loading 3D Model...</span>
        </div>
      </Html>
    );
  }

  return (
    <group ref={groupRef}>
      <primitive object={model} />
    </group>
  );
}

function LoadingIndicator() {
  return (
    <Html center>
      <div className="flex flex-col items-center gap-2">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
        <span className="text-white text-sm">Loading...</span>
      </div>
    </Html>
  );
}

export default function MeshViewer({
  fileUrl,
  fileFormat = 'glb',
  isAfterScan = false,
  useDemo = true, // Default to using demo files
}: MeshViewerProps) {
  // Determine which URL to use
  let modelUrl = fileUrl;
  
  // If useDemo is true or no valid URL, use demo files from public folder
  if (useDemo || !fileUrl || !fileUrl.startsWith('http')) {
    modelUrl = isAfterScan ? '/after_fitness.glb' : '/before_fitness.glb';
  }

  return (
    <div className="w-full h-full min-h-[400px] bg-gradient-to-b from-gray-800 to-gray-900 rounded-lg overflow-hidden relative">
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[0, 0.5, 2]} fov={50} />
        <OrbitControls
          enableDamping
          dampingFactor={0.05}
          minDistance={0.5}
          maxDistance={4}
          target={[0, 0, 0]}
          maxPolarAngle={Math.PI * 0.9}
        />
        
        {/* Lighting setup for better body visualization */}
        <ambientLight intensity={0.5} />
        <directionalLight 
          position={[3, 5, 3]} 
          intensity={1.2} 
          castShadow 
        />
        <directionalLight position={[-3, 3, -3]} intensity={0.6} />
        <pointLight position={[0, 3, 2]} intensity={0.4} color="#ffffff" />
        <hemisphereLight args={['#b1e1ff', '#b97a20', 0.4]} />
        
        {/* Floor */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.8, 0]} receiveShadow>
          <planeGeometry args={[10, 10]} />
          <meshStandardMaterial color="#1a1a2e" />
        </mesh>
        
        {/* Grid helper */}
        <gridHelper args={[4, 20, '#333355', '#222244']} position={[0, -0.79, 0]} />
        
        {/* 3D Model */}
        <Suspense fallback={<LoadingIndicator />}>
          <GLBModel url={modelUrl!} isAfterScan={isAfterScan} />
        </Suspense>
      </Canvas>
      
      {/* Controls hint */}
      <div className="absolute bottom-2 left-2 text-xs text-gray-400 bg-black/30 px-2 py-1 rounded">
        Drag to rotate • Scroll to zoom
      </div>
      
      {/* Scan type indicator */}
      <div className={`absolute top-2 right-2 text-xs px-2 py-1 rounded ${isAfterScan ? 'bg-green-500/80 text-white' : 'bg-blue-500/80 text-white'}`}>
        {isAfterScan ? 'After' : 'Before'}
      </div>
    </div>
  );
}

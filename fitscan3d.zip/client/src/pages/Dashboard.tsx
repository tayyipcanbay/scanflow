import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { 
  Activity, Camera, LineChart, MessageSquare, Upload, Utensils,
  TrendingUp, TrendingDown, Flame, Dumbbell, Target, Sparkles,
  ChevronRight, BarChart3, Zap, Heart, ArrowUpRight, User
} from "lucide-react";
import { Link, Redirect } from "wouter";

export default function Dashboard() {
  const { user, isAuthenticated, loading } = useAuth();
  const { data: profile } = trpc.profile.get.useQuery(undefined, { enabled: isAuthenticated });
  const { data: scans } = trpc.scans.list.useQuery(undefined, { enabled: isAuthenticated });
  const { data: comparisons } = trpc.comparisons.list.useQuery(undefined, { enabled: isAuthenticated });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-amber-50 via-white to-orange-50">
        <div className="text-center">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-amber-200 rounded-full animate-pulse"></div>
            <div className="absolute inset-0 w-16 h-16 border-4 border-t-amber-600 rounded-full animate-spin"></div>
          </div>
          <p className="mt-4 text-gray-600 font-medium">Loading your fitness data...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  const latestComparison = comparisons?.[0];
  const scanCount = scans?.length ?? 0;
  const comparisonCount = comparisons?.length ?? 0;
  
  // Calculate realistic body fat percentage (15-25% range)
  const bodyFatPercent = latestComparison?.bodyFatPercentage 
    ? Math.min(35, Math.max(8, latestComparison.bodyFatPercentage / 100))
    : null;
  
  // Calculate muscle change in kg
  const muscleChangeKg = latestComparison?.muscleMassChange 
    ? latestComparison.muscleMassChange / 1000
    : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-orange-50">
      {/* Colorful Header */}
      <header className="bg-gradient-to-r from-amber-600 via-orange-600 to-yellow-600 text-white shadow-lg">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                <Activity className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">🦫 Muscular Beavers</h1>
                <p className="text-white/80 text-sm">Build Your Dam Strong Body</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-white/90 font-medium">
                Welcome, {user?.name || user?.email?.split('@')[0]}
              </span>
              <Link href="/profile">
                <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-0">
                  <User className="w-4 h-4 mr-2" />
                  Profile
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Profile Setup Prompt */}
        {!profile && (
          <Card className="mb-6 border-2 border-dashed border-amber-300 bg-gradient-to-r from-amber-50 to-orange-50 overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-200/30 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-100 rounded-lg">
                  <Sparkles className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <CardTitle className="text-amber-900">Complete Your Profile</CardTitle>
                  <CardDescription className="text-amber-700">
                    Set up your profile to get personalized AI recommendations
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Link href="/profile">
                <Button className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
                  <Zap className="w-4 h-4 mr-2" />
                  Set Up Profile
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Stats Overview - Colorful Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="relative overflow-hidden bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 hover:shadow-xl hover:scale-[1.02] transition-all duration-300">
            <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Camera className="w-8 h-8 text-blue-200" />
                <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Total</span>
              </div>
              <CardDescription className="text-blue-100 mt-2">Total Scans</CardDescription>
              <CardTitle className="text-4xl font-bold">{scanCount}</CardTitle>
            </CardHeader>
          </Card>

          <Card className="relative overflow-hidden bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0 hover:shadow-xl hover:scale-[1.02] transition-all duration-300">
            <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <BarChart3 className="w-8 h-8 text-purple-200" />
                <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Analysis</span>
              </div>
              <CardDescription className="text-purple-100 mt-2">Comparisons</CardDescription>
              <CardTitle className="text-4xl font-bold">{comparisonCount}</CardTitle>
            </CardHeader>
          </Card>

          <Card className="relative overflow-hidden bg-gradient-to-br from-emerald-500 to-teal-600 text-white border-0 hover:shadow-xl hover:scale-[1.02] transition-all duration-300">
            <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Heart className="w-8 h-8 text-emerald-200" />
                {bodyFatPercent && bodyFatPercent < 20 ? (
                  <span className="text-xs bg-green-400/30 px-2 py-1 rounded-full flex items-center gap-1">
                    <TrendingDown className="w-3 h-3" /> Good
                  </span>
                ) : (
                  <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Health</span>
                )}
              </div>
              <CardDescription className="text-emerald-100 mt-2">Body Fat %</CardDescription>
              <CardTitle className="text-4xl font-bold">
                {bodyFatPercent ? `${bodyFatPercent.toFixed(1)}%` : "—"}
              </CardTitle>
            </CardHeader>
          </Card>

          <Card className="relative overflow-hidden bg-gradient-to-br from-rose-500 to-pink-600 text-white border-0 hover:shadow-xl hover:scale-[1.02] transition-all duration-300">
            <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Dumbbell className="w-8 h-8 text-rose-200" />
                {muscleChangeKg && muscleChangeKg > 0 ? (
                  <span className="text-xs bg-green-400/30 px-2 py-1 rounded-full flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" /> Gain
                  </span>
                ) : muscleChangeKg && muscleChangeKg < 0 ? (
                  <span className="text-xs bg-red-400/30 px-2 py-1 rounded-full flex items-center gap-1">
                    <TrendingDown className="w-3 h-3" /> Loss
                  </span>
                ) : (
                  <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Muscle</span>
                )}
              </div>
              <CardDescription className="text-rose-100 mt-2">Muscle Change</CardDescription>
              <CardTitle className="text-4xl font-bold">
                {muscleChangeKg ? `${muscleChangeKg > 0 ? '+' : ''}${muscleChangeKg.toFixed(2)} kg` : "—"}
              </CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Quick Actions - Interactive Cards */}
        <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-500" />
          Quick Actions
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Link href="/upload">
            <Card className="group cursor-pointer border-2 border-transparent hover:border-blue-400 bg-white hover:bg-gradient-to-br hover:from-blue-50 hover:to-indigo-50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="p-3 bg-blue-100 rounded-xl group-hover:bg-blue-200 transition-colors">
                    <Upload className="w-8 h-8 text-blue-600" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-gray-300 group-hover:text-blue-500 transition-colors" />
                </div>
                <CardTitle className="mt-4 group-hover:text-blue-700 transition-colors">Upload Scan</CardTitle>
                <CardDescription>
                  Upload a new 3D body scan (OBJ, GLB, or FBX)
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/compare">
            <Card className="group cursor-pointer border-2 border-transparent hover:border-purple-400 bg-white hover:bg-gradient-to-br hover:from-purple-50 hover:to-pink-50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="p-3 bg-purple-100 rounded-xl group-hover:bg-purple-200 transition-colors">
                    <LineChart className="w-8 h-8 text-purple-600" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-gray-300 group-hover:text-purple-500 transition-colors" />
                </div>
                <CardTitle className="mt-4 group-hover:text-purple-700 transition-colors">Compare Scans</CardTitle>
                <CardDescription>
                  Create a comparison between two scans
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/meal-plan">
            <Card className="group cursor-pointer border-2 border-transparent hover:border-green-400 bg-white hover:bg-gradient-to-br hover:from-green-50 hover:to-emerald-50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="p-3 bg-green-100 rounded-xl group-hover:bg-green-200 transition-colors">
                    <Utensils className="w-8 h-8 text-green-600" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-gray-300 group-hover:text-green-500 transition-colors" />
                </div>
                <CardTitle className="mt-4 group-hover:text-green-700 transition-colors">Meal Plan</CardTitle>
                <CardDescription>
                  Generate AI-powered weekly meal plan
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/exercises">
            <Card className="group cursor-pointer border-2 border-transparent hover:border-orange-400 bg-white hover:bg-gradient-to-br hover:from-orange-50 hover:to-amber-50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="p-3 bg-orange-100 rounded-xl group-hover:bg-orange-200 transition-colors">
                    <Flame className="w-8 h-8 text-orange-600" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-gray-300 group-hover:text-orange-500 transition-colors" />
                </div>
                <CardTitle className="mt-4 group-hover:text-orange-700 transition-colors">Exercises</CardTitle>
                <CardDescription>
                  Get targeted exercise recommendations
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/chat">
            <Card className="group cursor-pointer border-2 border-transparent hover:border-cyan-400 bg-white hover:bg-gradient-to-br hover:from-cyan-50 hover:to-teal-50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="p-3 bg-cyan-100 rounded-xl group-hover:bg-cyan-200 transition-colors">
                    <MessageSquare className="w-8 h-8 text-cyan-600" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-gray-300 group-hover:text-cyan-500 transition-colors" />
                </div>
                <CardTitle className="mt-4 group-hover:text-cyan-700 transition-colors">AI Coach</CardTitle>
                <CardDescription>
                  Chat with your personal fitness AI
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/scans">
            <Card className="group cursor-pointer border-2 border-transparent hover:border-indigo-400 bg-white hover:bg-gradient-to-br hover:from-indigo-50 hover:to-violet-50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="p-3 bg-indigo-100 rounded-xl group-hover:bg-indigo-200 transition-colors">
                    <Camera className="w-8 h-8 text-indigo-600" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-gray-300 group-hover:text-indigo-500 transition-colors" />
                </div>
                <CardTitle className="mt-4 group-hover:text-indigo-700 transition-colors">View Scans</CardTitle>
                <CardDescription>
                  Browse all your uploaded scans
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>
        </div>

        {/* Recent Activity */}
        <Card className="bg-white shadow-sm">
          <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-slate-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Target className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <CardTitle>Recent Comparisons</CardTitle>
                  <CardDescription>
                    Your latest body scan comparisons
                  </CardDescription>
                </div>
              </div>
              {comparisons && comparisons.length > 0 && (
                <Link href="/compare">
                  <Button variant="outline" size="sm">
                    View All
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </Link>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {comparisons && comparisons.length > 0 ? (
              <div className="divide-y">
                {comparisons.slice(0, 5).map((comp, index) => {
                  const compBodyFat = comp.bodyFatPercentage 
                    ? Math.min(35, Math.max(8, comp.bodyFatPercentage / 100))
                    : null;
                  const compMuscle = comp.muscleMassChange 
                    ? comp.muscleMassChange / 1000
                    : null;
                  
                  return (
                    <div 
                      key={comp.id} 
                      className="flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                          index === 0 ? 'bg-gradient-to-br from-blue-500 to-indigo-500' :
                          index === 1 ? 'bg-gradient-to-br from-purple-500 to-pink-500' :
                          index === 2 ? 'bg-gradient-to-br from-green-500 to-teal-500' :
                          'bg-gradient-to-br from-gray-400 to-gray-500'
                        }`}>
                          #{comp.id}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">
                            Comparison #{comp.id}
                          </p>
                          <p className="text-sm text-gray-500">
                            {new Date(comp.createdAt).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric'
                            })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <div className="flex items-center gap-2">
                            <Heart className="w-4 h-4 text-emerald-500" />
                            <span className="font-semibold text-gray-900">
                              {compBodyFat ? `${compBodyFat.toFixed(1)}%` : "—"}
                            </span>
                          </div>
                          <p className="text-xs text-gray-500">Body Fat</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-2">
                            <Dumbbell className="w-4 h-4 text-rose-500" />
                            <span className={`font-semibold ${
                              compMuscle && compMuscle > 0 ? 'text-green-600' : 
                              compMuscle && compMuscle < 0 ? 'text-red-600' : 'text-gray-900'
                            }`}>
                              {compMuscle ? `${compMuscle > 0 ? '+' : ''}${compMuscle.toFixed(2)} kg` : "—"}
                            </span>
                          </div>
                          <p className="text-xs text-gray-500">Muscle</p>
                        </div>
                        <Link href={`/comparison/${comp.id}`}>
                          <Button variant="outline" size="sm" className="hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-300">
                            View
                            <ChevronRight className="w-4 h-4 ml-1" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                  <LineChart className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-600 font-medium">No comparisons yet</p>
                <p className="text-gray-500 text-sm mt-1">Upload scans to get started!</p>
                <Link href="/upload">
                  <Button className="mt-4 bg-gradient-to-r from-blue-600 to-indigo-600">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Your First Scan
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

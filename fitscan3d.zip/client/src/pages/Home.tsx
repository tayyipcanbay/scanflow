import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { Activity, Brain, Camera, LineChart, Utensils, Zap } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-amber-100 via-orange-50 to-yellow-100 py-20">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <div className="text-6xl mb-4">🦫</div>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight">
              <span className="text-amber-800">Muscular Beavers</span>
              <span className="block text-amber-600 text-3xl md:text-4xl mt-2">Build Your Dam Strong Body</span>
            </h1>
            <p className="text-xl text-amber-900/70 max-w-2xl mx-auto">
              Upload 3D body scans, visualize changes with color-coded regions, and get AI-powered meal plans and exercise recommendations tailored to your transformation.
            </p>
            <div className="flex gap-4 justify-center pt-4">
              {isAuthenticated ? (
                <Link href="/dashboard">
                  <Button size="lg" className="text-lg px-8 bg-amber-600 hover:bg-amber-700">
                    Go to Dashboard
                  </Button>
                </Link>
              ) : (
                <>
                  <Link href="/register">
                    <Button size="lg" className="text-lg px-8 bg-amber-600 hover:bg-amber-700">
                      Get Started Free
                    </Button>
                  </Link>
                  <Button size="lg" variant="outline" className="text-lg px-8 border-amber-600 text-amber-700 hover:bg-amber-100" asChild>
                    <a href="#features">Learn More</a>
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gradient-to-b from-white to-amber-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-amber-900">Powerful Features</h2>
            <p className="text-lg text-amber-700 max-w-2xl mx-auto">
              Everything you need to track, analyze, and optimize your fitness journey
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <Card className="border-amber-200 bg-gradient-to-br from-white to-amber-50">
              <CardHeader>
                <Camera className="w-10 h-10 text-amber-600 mb-2" />
                <CardTitle className="text-amber-900">3D Body Scanning</CardTitle>
                <CardDescription className="text-amber-700">
                  Upload OBJ, GLB, or FBX mesh files from body scanners. Track your transformation over time with precise measurements.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-orange-200 bg-gradient-to-br from-white to-orange-50">
              <CardHeader>
                <Zap className="w-10 h-10 text-orange-600 mb-2" />
                <CardTitle className="text-orange-900">Color-Coded Visualization</CardTitle>
                <CardDescription className="text-orange-700">
                  See exactly where you're gaining muscle (red) and losing fat (blue/green). Interactive 3D viewer shows every detail.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-yellow-200 bg-gradient-to-br from-white to-yellow-50">
              <CardHeader>
                <LineChart className="w-10 h-10 text-yellow-600 mb-2" />
                <CardTitle className="text-yellow-900">Body Composition Analysis</CardTitle>
                <CardDescription className="text-yellow-700">
                  Get accurate body fat percentage, muscle mass changes, and region-specific metrics from your scans.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-green-200 bg-gradient-to-br from-white to-green-50">
              <CardHeader>
                <Utensils className="w-10 h-10 text-green-600 mb-2" />
                <CardTitle className="text-green-900">AI Meal Plans</CardTitle>
                <CardDescription className="text-green-700">
                  Personalized weekly meal plans based on your body composition, goals, and progress. Bulking, cutting, or maintaining.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-blue-200 bg-gradient-to-br from-white to-blue-50">
              <CardHeader>
                <Activity className="w-10 h-10 text-blue-600 mb-2" />
                <CardTitle className="text-blue-900">Smart Exercise Recommendations</CardTitle>
                <CardDescription className="text-blue-700">
                  Targeted workouts for specific body regions. AI adapts to your progress and avoids exercises that may cause injury.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-purple-200 bg-gradient-to-br from-white to-purple-50">
              <CardHeader>
                <Brain className="w-10 h-10 text-purple-600 mb-2" />
                <CardTitle className="text-purple-900">AI Fitness Coach</CardTitle>
                <CardDescription className="text-purple-700">
                  Chat with your personal AI coach. Get advice on nutrition, workouts, and injury prevention based on your scan data.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-amber-900">How It Works</h2>
            <p className="text-lg text-amber-700 max-w-2xl mx-auto">
              Simple, powerful, and effective
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-amber-600 text-white flex items-center justify-center font-bold text-xl">
                1
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-amber-900">Upload Your Baseline Scan</h3>
                <p className="text-amber-700">
                  Get a 3D body scan from any compatible scanner (many gyms and fitness centers offer this). Upload the mesh file to Muscular Beavers.
                </p>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-orange-600 text-white flex items-center justify-center font-bold text-xl">
                2
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-orange-900">Follow Your AI-Generated Plan</h3>
                <p className="text-orange-700">
                  Get personalized meal plans and exercise recommendations. Chat with your AI coach for guidance and motivation.
                </p>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-yellow-600 text-white flex items-center justify-center font-bold text-xl">
                3
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-yellow-900">Upload Progress Scans</h3>
                <p className="text-yellow-700">
                  Every 4-8 weeks, upload a new scan. See color-coded visualizations showing exactly where you've gained muscle and lost fat.
                </p>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center font-bold text-xl">
                4
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-green-900">Optimize and Repeat</h3>
                <p className="text-green-700">
                  AI adjusts your meal plans and exercises based on your progress. Keep improving with data-driven insights.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 via-orange-600 to-yellow-600 text-white">
        <div className="container text-center">
          <div className="text-5xl mb-4">🦫💪</div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Build Your Dam Strong Body?
          </h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Join thousands of beavers tracking their fitness journey with precision and AI-powered guidance.
          </p>
          {isAuthenticated ? (
            <Link href="/dashboard">
              <Button size="lg" variant="secondary" className="text-lg px-8">
                Go to Dashboard
              </Button>
            </Link>
          ) : (
            <Link href="/register">
              <Button size="lg" variant="secondary" className="text-lg px-8">
                Start Your Journey
              </Button>
            </Link>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t bg-amber-50">
        <div className="container text-center text-sm text-amber-700">
          <p>© 2026 Muscular Beavers 🦫 Build your dam strong body with AI-powered insights.</p>
        </div>
      </footer>
    </div>
  );
}

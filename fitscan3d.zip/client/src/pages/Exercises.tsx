import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { 
  Dumbbell, Sparkles, ArrowLeft, AlertCircle, Flame, Clock, 
  Target, Zap, Heart, TrendingUp, ChevronRight, Play, 
  RotateCcw, Loader2, Trophy, Star
} from "lucide-react";
import { useState } from "react";
import { Link, Redirect, useLocation } from "wouter";
import { toast } from "sonner";

// Color mapping for different body regions
const regionColors: Record<string, { bg: string; text: string; icon: string; gradient: string }> = {
  chest: { bg: "bg-red-100", text: "text-red-700", icon: "💪", gradient: "from-red-500 to-orange-500" },
  arms: { bg: "bg-orange-100", text: "text-orange-700", icon: "🦾", gradient: "from-orange-500 to-yellow-500" },
  shoulders: { bg: "bg-amber-100", text: "text-amber-700", icon: "🏋️", gradient: "from-amber-500 to-yellow-500" },
  waist: { bg: "bg-cyan-100", text: "text-cyan-700", icon: "🔥", gradient: "from-cyan-500 to-blue-500" },
  thighs: { bg: "bg-purple-100", text: "text-purple-700", icon: "🦵", gradient: "from-purple-500 to-pink-500" },
  hips: { bg: "bg-pink-100", text: "text-pink-700", icon: "🍑", gradient: "from-pink-500 to-rose-500" },
  calves: { bg: "bg-indigo-100", text: "text-indigo-700", icon: "🦶", gradient: "from-indigo-500 to-purple-500" },
  full_body: { bg: "bg-green-100", text: "text-green-700", icon: "⚡", gradient: "from-green-500 to-emerald-500" },
  general: { bg: "bg-blue-100", text: "text-blue-700", icon: "🎯", gradient: "from-blue-500 to-indigo-500" },
};

// Intensity colors
const intensityColors: Record<string, { bg: string; text: string }> = {
  low: { bg: "bg-green-500", text: "text-white" },
  moderate: { bg: "bg-yellow-500", text: "text-black" },
  high: { bg: "bg-red-500", text: "text-white" },
};

export default function Exercises() {
  const { isAuthenticated, loading } = useAuth();
  const utils = trpc.useUtils();
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1]);
  const comparisonId = searchParams.get('comparisonId');
  
  const [injuries, setInjuries] = useState<string[]>([]);
  const [injuryInput, setInjuryInput] = useState("");

  // Get user's comparisons to select from
  const { data: comparisons } = trpc.comparisons.list.useQuery(undefined, { enabled: isAuthenticated });
  const [selectedComparisonId, setSelectedComparisonId] = useState<number | null>(comparisonId ? parseInt(comparisonId) : null);

  const { data: exercises, isLoading, refetch } = trpc.ai.getExercises.useQuery(
    { comparisonId: selectedComparisonId || 0 },
    { enabled: isAuthenticated && !!selectedComparisonId }
  );

  const generateMutation = trpc.ai.generateExercises.useMutation({
    onSuccess: () => {
      toast.success("🎉 Exercise plan generated successfully!");
      utils.ai.getExercises.invalidate();
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Failed to generate exercises: ${error.message}`);
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-purple-50">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto" />
          <p className="mt-4 text-muted-foreground">Loading your fitness plan...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  const handleAddInjury = () => {
    if (injuryInput.trim()) {
      setInjuries([...injuries, injuryInput.trim()]);
      setInjuryInput("");
    }
  };

  const handleRemoveInjury = (index: number) => {
    setInjuries(injuries.filter((_, i) => i !== index));
  };

  const handleGenerate = () => {
    if (!selectedComparisonId) {
      toast.error("Please select a comparison first");
      return;
    }

    generateMutation.mutate({
      comparisonId: selectedComparisonId,
      injuries: injuries.length > 0 ? injuries : undefined,
    });
  };

  // Group exercises by target region
  const groupedExercises = exercises?.reduce((acc: any, ex: any) => {
    const region = ex.targetRegion || 'general';
    if (!acc[region]) acc[region] = [];
    acc[region].push(ex);
    return acc;
  }, {}) || {};

  const totalExercises = exercises?.length || 0;
  const totalSets = exercises?.reduce((sum: number, ex: any) => sum + (ex.sets || 0), 0) || 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Colorful Header */}
      <header className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white">
        <div className="container py-6">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="mb-4 text-white/80 hover:text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <Dumbbell className="w-10 h-10" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">AI Exercise Plan</h1>
              <p className="text-white/80">Personalized workouts based on your body scan</p>
            </div>
          </div>
          
          {/* Stats Bar */}
          {totalExercises > 0 && (
            <div className="flex gap-6 mt-6">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-white/80" />
                <span className="font-semibold">{totalExercises} Exercises</span>
              </div>
              <div className="flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-white/80" />
                <span className="font-semibold">{totalSets} Total Sets</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-white/80" />
                <span className="font-semibold">~45-60 min</span>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="max-w-5xl mx-auto space-y-8">
          {/* Comparison Selector */}
          {comparisons && comparisons.length > 0 && (
            <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Target className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle className="text-blue-900">Select Body Scan Comparison</CardTitle>
                    <CardDescription className="text-blue-700">
                      Choose which scan comparison to base your exercises on
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {comparisons.map((comp: any) => (
                    <button
                      key={comp.id}
                      onClick={() => setSelectedComparisonId(comp.id)}
                      className={`p-4 rounded-xl border-2 transition-all text-left ${
                        selectedComparisonId === comp.id
                          ? 'border-blue-500 bg-blue-100 shadow-lg scale-[1.02]'
                          : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50'
                      }`}
                    >
                      <p className="font-bold text-gray-900">Comparison #{comp.id}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(comp.createdAt).toLocaleDateString()}
                      </p>
                      {comp.bodyFatPercentage && (
                        <p className="text-xs text-blue-600 mt-1">
                          Body Fat: {Math.min(35, Math.max(8, comp.bodyFatPercentage / 100)).toFixed(1)}%
                        </p>
                      )}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Injury/Concern Input Card */}
          <Card className="border-2 border-dashed border-orange-200 bg-gradient-to-r from-orange-50 to-amber-50">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 rounded-lg">
                  <Heart className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <CardTitle className="text-orange-900">Customize Your Plan</CardTitle>
                  <CardDescription className="text-orange-700">
                    Tell us about any injuries so we can adjust exercises for you
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="e.g., Knee pain, Lower back injury, Shoulder issues..."
                    value={injuryInput}
                    onChange={(e) => setInjuryInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAddInjury()}
                    className="border-orange-200 focus:border-orange-400"
                  />
                </div>
                <Button onClick={handleAddInjury} className="bg-orange-500 hover:bg-orange-600">
                  Add
                </Button>
              </div>

              {injuries.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {injuries.map((injury, index) => (
                    <div
                      key={index}
                      className="bg-orange-200 text-orange-800 px-4 py-2 rounded-full text-sm flex items-center gap-2 font-medium"
                    >
                      <AlertCircle className="w-4 h-4" />
                      {injury}
                      <button
                        onClick={() => handleRemoveInjury(index)}
                        className="hover:text-orange-900 ml-1"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <Button
                onClick={handleGenerate}
                disabled={!selectedComparisonId || generateMutation.isPending}
                className="w-full h-12 text-lg bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                {generateMutation.isPending ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Generating Your Plan...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    {exercises && exercises.length > 0 ? 'Regenerate' : 'Generate'} Exercise Plan
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Exercise Plan Display */}
          {isLoading ? (
            <div className="text-center py-12">
              <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto" />
              <p className="mt-4 text-muted-foreground">Loading exercises...</p>
            </div>
          ) : Object.keys(groupedExercises).length > 0 ? (
            <div className="space-y-8">
              {Object.entries(groupedExercises).map(([region, regionExercises]: [string, any]) => {
                const colors = regionColors[region] || regionColors.general;
                
                return (
                  <div key={region} className="space-y-4">
                    {/* Region Header */}
                    <div className={`flex items-center gap-3 p-4 rounded-xl bg-gradient-to-r ${colors.gradient} text-white`}>
                      <span className="text-3xl">{colors.icon}</span>
                      <div>
                        <h2 className="text-xl font-bold capitalize">
                          {region === 'general' ? 'Full Body' : region} Exercises
                        </h2>
                        <p className="text-white/80 text-sm">
                          {regionExercises.length} exercise{regionExercises.length > 1 ? 's' : ''} for this region
                        </p>
                      </div>
                    </div>

                    {/* Exercise Cards */}
                    <div className="grid md:grid-cols-2 gap-4">
                      {regionExercises.map((exercise: any, index: number) => {
                        const intensity = intensityColors[exercise.intensity] || intensityColors.moderate;
                        
                        return (
                          <Card key={exercise.id || index} className="overflow-hidden hover:shadow-lg transition-shadow">
                            <div className={`h-2 bg-gradient-to-r ${colors.gradient}`} />
                            <CardContent className="p-5">
                              <div className="flex items-start justify-between mb-3">
                                <h3 className="font-bold text-lg text-gray-900">{exercise.exerciseName}</h3>
                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${intensity.bg} ${intensity.text}`}>
                                  {exercise.intensity?.toUpperCase()}
                                </span>
                              </div>
                              
                              {/* Sets/Reps Display */}
                              <div className="flex gap-3 mb-4">
                                <div className="flex items-center gap-2 bg-gray-100 px-3 py-2 rounded-lg">
                                  <RotateCcw className="w-4 h-4 text-gray-600" />
                                  <span className="font-semibold text-gray-800">{exercise.sets} sets</span>
                                </div>
                                <div className="flex items-center gap-2 bg-gray-100 px-3 py-2 rounded-lg">
                                  <Zap className="w-4 h-4 text-gray-600" />
                                  <span className="font-semibold text-gray-800">{exercise.reps} reps</span>
                                </div>
                              </div>
                              
                              {/* Description */}
                              <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-line">
                                {exercise.description}
                              </p>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                );
              })}

              {/* AI Insights Card */}
              <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-emerald-100 rounded-lg">
                      <Trophy className="w-6 h-6 text-emerald-600" />
                    </div>
                    <div>
                      <CardTitle className="text-emerald-900">AI Trainer Tips</CardTitle>
                      <CardDescription className="text-emerald-700">
                        Expert recommendations for best results
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3 p-3 bg-white/60 rounded-lg">
                      <Star className="w-5 h-5 text-yellow-500 mt-0.5" />
                      <div>
                        <p className="font-medium text-emerald-900">Progressive Overload</p>
                        <p className="text-sm text-emerald-700">Gradually increase weight or reps each week</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-white/60 rounded-lg">
                      <Star className="w-5 h-5 text-yellow-500 mt-0.5" />
                      <div>
                        <p className="font-medium text-emerald-900">Rest & Recovery</p>
                        <p className="text-sm text-emerald-700">48-72 hours between training same muscles</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-white/60 rounded-lg">
                      <Star className="w-5 h-5 text-yellow-500 mt-0.5" />
                      <div>
                        <p className="font-medium text-emerald-900">Form First</p>
                        <p className="text-sm text-emerald-700">Prioritize proper form over heavier weights</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-white/60 rounded-lg">
                      <Star className="w-5 h-5 text-yellow-500 mt-0.5" />
                      <div>
                        <p className="font-medium text-emerald-900">Track Progress</p>
                        <p className="text-sm text-emerald-700">Log your workouts to monitor improvements</p>
                      </div>
                    </div>
                  </div>
                  {injuries.length > 0 && (
                    <div className="mt-4 p-3 bg-orange-100 rounded-lg flex items-center gap-3">
                      <AlertCircle className="w-5 h-5 text-orange-600" />
                      <p className="text-sm text-orange-800 font-medium">
                        Exercises modified to accommodate your reported concerns
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            /* Empty State */
            <Card className="text-center py-16 bg-gradient-to-br from-gray-50 to-slate-100">
              <CardContent>
                <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center">
                  <Dumbbell className="w-12 h-12 text-indigo-500" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">No Exercise Plan Yet</h2>
                <p className="text-gray-600 mb-8 max-w-md mx-auto">
                  {selectedComparisonId 
                    ? "Generate your personalized AI exercise plan based on your body scan analysis"
                    : comparisons && comparisons.length > 0 
                      ? "Select a comparison above to generate targeted exercises"
                      : "Create a body scan comparison first to get targeted exercises"}
                </p>
                {selectedComparisonId ? (
                  <Button
                    onClick={handleGenerate}
                    disabled={generateMutation.isPending}
                    size="lg"
                    className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                  >
                    {generateMutation.isPending ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate Exercise Plan
                      </>
                    )}
                  </Button>
                ) : comparisons && comparisons.length > 0 ? (
                  <p className="text-blue-600 font-medium">👆 Select a comparison above to get started</p>
                ) : (
                  <Link href="/compare">
                    <Button size="lg" className="bg-gradient-to-r from-indigo-600 to-purple-600">
                      <ChevronRight className="w-5 h-5 mr-2" />
                      Create Comparison First
                    </Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Camera, Upload, Calendar, FileType } from "lucide-react";
import { Link, Redirect } from "wouter";

export default function Scans() {
  const { isAuthenticated, loading } = useAuth();
  const { data: scans, isLoading } = trpc.scans.list.useQuery(undefined, { enabled: isAuthenticated });

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="bg-background border-b">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Camera className="w-8 h-8 text-primary" />
              <h1 className="text-2xl font-bold">My Scans</h1>
            </div>
            <div className="flex gap-2">
              <Link href="/upload">
                <Button>
                  <Upload className="w-4 h-4 mr-2" />
                  Upload New Scan
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" size="sm">Back to Dashboard</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {scans && scans.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {scans.map((scan) => (
              <Card key={scan.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{scan.fileName}</CardTitle>
                      <CardDescription className="flex items-center gap-1 mt-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(scan.scanDate).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <div className="bg-primary/10 text-primary px-2 py-1 rounded text-xs font-medium uppercase">
                      {scan.fileFormat}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="text-muted-foreground">File Size</p>
                        <p className="font-medium">{scan.fileSize ? (scan.fileSize / 1024 / 1024).toFixed(2) : "—"} MB</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Vertices</p>
                        <p className="font-medium">{scan.vertexCount?.toLocaleString() || "—"}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Volume</p>
                        <p className="font-medium">
                          {scan.meshVolume ? `${(scan.meshVolume / 1000).toFixed(2)} L` : "—"}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Surface</p>
                        <p className="font-medium">
                          {scan.surfaceArea ? `${(scan.surfaceArea / 1000).toFixed(2)} m²` : "—"}
                        </p>
                      </div>
                    </div>

                    <div className="pt-3 border-t flex gap-2">
                      <Button variant="outline" size="sm" className="flex-1" asChild>
                        <a href={scan.fileUrl} target="_blank" rel="noopener noreferrer">
                          <FileType className="w-4 h-4 mr-1" />
                          View File
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>No Scans Yet</CardTitle>
              <CardDescription>
                Upload your first 3D body scan to start tracking your fitness progress
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center py-8">
              <Camera className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-6">
                Get started by uploading a scan from a compatible body scanner
              </p>
              <Link href="/upload">
                <Button>
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Your First Scan
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}

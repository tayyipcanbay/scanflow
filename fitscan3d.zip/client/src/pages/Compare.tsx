import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { 
  GitCompare, ArrowLeft, Sparkles, TrendingUp, TrendingDown, 
  Activity, Target, Zap, Camera, ArrowRight, Loader2,
  ChevronRight, BarChart3, Upload
} from "lucide-react";
import { useState } from "react";
import { Link, Redirect, useLocation } from "wouter";
import { toast } from "sonner";

export default function Compare() {
  const { isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const { data: scans, isLoading } = trpc.scans.list.useQuery(undefined, { enabled: isAuthenticated });
  
  const [baselineScanId, setBaselineScanId] = useState("");
  const [comparisonScanId, setComparisonScanId] = useState("");

  const createComparisonMutation = trpc.comparisons.create.useMutation({
    onSuccess: (data) => {
      toast.success("🎉 Comparison created successfully!");
      setLocation(`/comparison/${data.comparisonId}`);
    },
    onError: (error) => {
      toast.error(`Failed to create comparison: ${error.message}`);
    },
  });

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-amber-50 via-white to-orange-50">
        <div className="text-center">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-amber-200 rounded-full animate-pulse"></div>
            <div className="absolute inset-0 w-16 h-16 border-4 border-t-amber-600 rounded-full animate-spin"></div>
          </div>
          <p className="mt-4 text-gray-600 font-medium">Loading your scans...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  const handleCreateComparison = () => {
    if (!baselineScanId || !comparisonScanId) {
      toast.error("Please select both baseline and comparison scans");
      return;
    }

    if (baselineScanId === comparisonScanId) {
      toast.error("Please select different scans for comparison");
      return;
    }

    createComparisonMutation.mutate({
      baselineScanId: parseInt(baselineScanId),
      comparisonScanId: parseInt(comparisonScanId),
    });
  };

  const sortedScans = scans?.sort((a, b) => 
    new Date(a.scanDate).getTime() - new Date(b.scanDate).getTime()
  );

  const selectedBaseline = sortedScans?.find(s => s.id.toString() === baselineScanId);
  const selectedComparison = sortedScans?.find(s => s.id.toString() === comparisonScanId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-orange-50">
      {/* Colorful Header */}
      <header className="bg-gradient-to-r from-amber-600 via-orange-600 to-yellow-600 text-white shadow-lg">
        <div className="container py-6">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="mb-4 text-white/80 hover:text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <GitCompare className="w-10 h-10" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">🦫 Compare Scans</h1>
              <p className="text-white/80">Visualize your dam strong transformation</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {scans && scans.length >= 2 ? (
            <>
              {/* Scan Selection Cards */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Baseline Scan Card */}
                <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50 overflow-hidden">
                  <div className="h-2 bg-gradient-to-r from-blue-500 to-indigo-500" />
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Camera className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <CardTitle className="text-blue-900">Before Scan</CardTitle>
                        <CardDescription className="text-blue-700">
                          Your starting point
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select value={baselineScanId} onValueChange={setBaselineScanId}>
                      <SelectTrigger className="border-blue-300 bg-white focus:border-blue-500 h-12">
                        <SelectValue placeholder="Select baseline scan" />
                      </SelectTrigger>
                      <SelectContent>
                        {sortedScans?.map((scan) => (
                          <SelectItem key={scan.id} value={scan.id.toString()}>
                            <div className="flex items-center gap-2">
                              <Camera className="w-4 h-4 text-blue-500" />
                              <span>{scan.fileName}</span>
                              <span className="text-gray-500">
                                - {new Date(scan.scanDate).toLocaleDateString()}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {selectedBaseline && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-blue-200">
                        <p className="font-semibold text-blue-900">{selectedBaseline.fileName}</p>
                        <p className="text-sm text-blue-700">
                          📅 {new Date(selectedBaseline.scanDate).toLocaleDateString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Comparison Scan Card */}
                <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 overflow-hidden">
                  <div className="h-2 bg-gradient-to-r from-green-500 to-emerald-500" />
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <Target className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <CardTitle className="text-green-900">After Scan</CardTitle>
                        <CardDescription className="text-green-700">
                          Your progress
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select value={comparisonScanId} onValueChange={setComparisonScanId}>
                      <SelectTrigger className="border-green-300 bg-white focus:border-green-500 h-12">
                        <SelectValue placeholder="Select comparison scan" />
                      </SelectTrigger>
                      <SelectContent>
                        {sortedScans?.map((scan) => (
                          <SelectItem key={scan.id} value={scan.id.toString()}>
                            <div className="flex items-center gap-2">
                              <Target className="w-4 h-4 text-green-500" />
                              <span>{scan.fileName}</span>
                              <span className="text-gray-500">
                                - {new Date(scan.scanDate).toLocaleDateString()}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {selectedComparison && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-green-200">
                        <p className="font-semibold text-green-900">{selectedComparison.fileName}</p>
                        <p className="text-sm text-green-700">
                          📅 {new Date(selectedComparison.scanDate).toLocaleDateString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Visual Flow Indicator */}
              {selectedBaseline && selectedComparison && (
                <div className="flex items-center justify-center gap-4 py-4">
                  <div className="flex items-center gap-2 px-4 py-2 bg-blue-100 rounded-full">
                    <Camera className="w-5 h-5 text-blue-600" />
                    <span className="font-medium text-blue-800">Before</span>
                  </div>
                  <div className="flex items-center">
                    <ArrowRight className="w-8 h-8 text-purple-500" />
                    <Sparkles className="w-6 h-6 text-yellow-500 -ml-2" />
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-green-100 rounded-full">
                    <Target className="w-5 h-5 text-green-600" />
                    <span className="font-medium text-green-800">After</span>
                  </div>
                </div>
              )}

              {/* What You'll Get - Colorful Cards */}
              <Card className="border-0 shadow-lg overflow-hidden">
                <div className="h-2 bg-gradient-to-r from-red-500 via-yellow-500 via-green-500 to-blue-500" />
                <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-100 rounded-lg">
                      <Sparkles className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <CardTitle className="text-purple-900">What You'll Discover</CardTitle>
                      <CardDescription className="text-purple-700">
                        AI-powered body transformation analysis
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-red-50 to-orange-50 rounded-xl border border-red-200">
                      <div className="p-2 bg-red-100 rounded-lg">
                        <TrendingUp className="w-5 h-5 text-red-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-red-900">Muscle Gain</p>
                        <p className="text-sm text-red-700">Red/Orange regions show volume increase</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl border border-cyan-200">
                      <div className="p-2 bg-cyan-100 rounded-lg">
                        <TrendingDown className="w-5 h-5 text-cyan-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-cyan-900">Fat Loss</p>
                        <p className="text-sm text-cyan-700">Blue/Green regions show volume decrease</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl border border-emerald-200">
                      <div className="p-2 bg-emerald-100 rounded-lg">
                        <BarChart3 className="w-5 h-5 text-emerald-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-emerald-900">Body Composition</p>
                        <p className="text-sm text-emerald-700">Body fat % and muscle mass changes</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <Activity className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-purple-900">Region Metrics</p>
                        <p className="text-sm text-purple-700">Waist, chest, arms, thighs analysis</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Create Comparison Button */}
              <div className="flex gap-4">
                <Button
                  onClick={handleCreateComparison}
                  disabled={!baselineScanId || !comparisonScanId || createComparisonMutation.isPending}
                  className="flex-1 h-14 text-lg bg-gradient-to-r from-amber-600 via-orange-600 to-yellow-600 hover:from-amber-700 hover:via-orange-700 hover:to-yellow-700 shadow-lg"
                >
                  {createComparisonMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Analyzing Your Transformation...
                    </>
                  ) : (
                    <>
                      <Zap className="w-5 h-5 mr-2" />
                      Create Comparison
                      <ChevronRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>
              </div>
            </>
          ) : (
            /* Not Enough Scans */
            <Card className="text-center py-16 bg-gradient-to-br from-amber-50 to-orange-100 border-2 border-dashed border-amber-300">
              <CardContent>
                <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-amber-100 to-orange-100 rounded-full flex items-center justify-center">
                  <GitCompare className="w-12 h-12 text-amber-600" />
                </div>
                <h2 className="text-2xl font-bold text-amber-900 mb-2">Need More Scans 🦫</h2>
                <p className="text-amber-700 mb-2">
                  You have <span className="font-bold text-amber-600">{scans?.length || 0}</span> scan{scans?.length !== 1 ? 's' : ''}
                </p>
                <p className="text-amber-600 mb-8 max-w-md mx-auto">
                  Upload at least 2 body scans to compare your transformation progress
                </p>
                <Link href="/upload">
                  <Button size="lg" className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700">
                    <Upload className="w-5 h-5 mr-2" />
                    Upload Your Scans
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

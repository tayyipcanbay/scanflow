import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Upload as UploadIcon, FileUp, CheckCircle2, AlertCircle } from "lucide-react";
import { useState } from "react";
import { Link, Redirect, useLocation } from "wouter";
import { toast } from "sonner";

export default function Upload() {
  const { isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [file, setFile] = useState<File | null>(null);
  const [scanDate, setScanDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState("");
  const [isDragging, setIsDragging] = useState(false);

  const uploadMutation = trpc.scans.upload.useMutation({
    onSuccess: () => {
      toast.success("Scan uploaded successfully!");
      setFile(null);
      setNotes("");
      setLocation("/scans");
    },
    onError: (error) => {
      toast.error(`Upload failed: ${error.message}`);
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      validateAndSetFile(droppedFile);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      validateAndSetFile(selectedFile);
    }
  };

  const validateAndSetFile = (selectedFile: File) => {
    const validExtensions = ['.obj', '.glb', '.fbx'];
    const fileExtension = selectedFile.name.toLowerCase().slice(selectedFile.name.lastIndexOf('.'));

    if (!validExtensions.includes(fileExtension)) {
      toast.error("Invalid file format. Please upload OBJ, GLB, or FBX files.");
      return;
    }

    if (selectedFile.size > 50 * 1024 * 1024) { // 50MB limit
      toast.error("File too large. Maximum size is 50MB.");
      return;
    }

    setFile(selectedFile);
    toast.success(`File selected: ${selectedFile.name}`);
  };

  const handleUpload = async () => {
    if (!file) {
      toast.error("Please select a file first");
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      const content = e.target?.result as string;
      const base64Content = content.split(',')[1] || content;

      const fileFormat = file.name.toLowerCase().endsWith('.obj') ? 'obj' :
                        file.name.toLowerCase().endsWith('.glb') ? 'glb' : 'fbx';

      uploadMutation.mutate({
        fileName: file.name,
        fileFormat,
        fileSize: file.size,
        scanDate: new Date(scanDate),
        fileContent: base64Content,
      });
    };

    reader.readAsDataURL(file);
  };

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="bg-background border-b">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <UploadIcon className="w-8 h-8 text-primary" />
              <h1 className="text-2xl font-bold">Upload Body Scan</h1>
            </div>
            <Link href="/dashboard">
              <Button variant="outline" size="sm">Back to Dashboard</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="max-w-3xl mx-auto">
          {/* Instructions */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Upload Instructions</CardTitle>
              <CardDescription>
                Upload your 3D body scan file to track your fitness progress
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>✓ Supported formats: OBJ, GLB, FBX</li>
                <li>✓ Maximum file size: 50MB</li>
                <li>✓ Get scans from compatible body scanners (available at many gyms)</li>
                <li>✓ Upload regularly (every 4-8 weeks) to track progress</li>
              </ul>
            </CardContent>
          </Card>

          {/* Upload Area */}
          <Card>
            <CardHeader>
              <CardTitle>Select File</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Drag and Drop Zone */}
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`
                  border-2 border-dashed rounded-lg p-12 text-center transition-colors
                  ${isDragging ? 'border-primary bg-primary/5' : 'border-muted-foreground/25'}
                  ${file ? 'bg-green-50 border-green-500' : ''}
                `}
              >
                {file ? (
                  <div className="space-y-4">
                    <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto" />
                    <div>
                      <p className="text-lg font-semibold text-green-700">{file.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => setFile(null)}
                    >
                      Remove File
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <FileUp className="w-16 h-16 text-muted-foreground mx-auto" />
                    <div>
                      <p className="text-lg font-semibold mb-2">
                        Drag and drop your scan file here
                      </p>
                      <p className="text-sm text-muted-foreground mb-4">
                        or click to browse
                      </p>
                    </div>
                    <div>
                      <input
                        type="file"
                        id="file-input"
                        className="hidden"
                        accept=".obj,.glb,.fbx"
                        onChange={handleFileSelect}
                      />
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById('file-input')?.click()}
                      >
                        Browse Files
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {/* Scan Details */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="scanDate">Scan Date</Label>
                  <Input
                    id="scanDate"
                    type="date"
                    value={scanDate}
                    onChange={(e) => setScanDate(e.target.value)}
                    max={new Date().toISOString().split('T')[0]}
                  />
                </div>

                <div>
                  <Label htmlFor="notes">Notes (Optional)</Label>
                  <Input
                    id="notes"
                    placeholder="e.g., After 8 weeks of training, feeling stronger"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>
              </div>

              {/* Upload Button */}
              <div className="flex gap-3">
                <Button
                  onClick={handleUpload}
                  disabled={!file || uploadMutation.isPending}
                  className="flex-1"
                >
                  {uploadMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Uploading...
                    </>
                  ) : (
                    <>
                      <UploadIcon className="w-4 h-4 mr-2" />
                      Upload Scan
                    </>
                  )}
                </Button>
                <Link href="/dashboard">
                  <Button variant="outline">Cancel</Button>
                </Link>
              </div>

              {uploadMutation.isError && (
                <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-destructive">Upload Failed</p>
                    <p className="text-sm text-destructive/80">{uploadMutation.error.message}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

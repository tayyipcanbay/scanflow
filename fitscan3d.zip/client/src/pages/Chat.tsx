import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";
import { Bot, Send, User } from "lucide-react";
import { useState } from "react";
import { Link, Redirect } from "wouter";
import { toast } from "sonner";

export default function Chat() {
  const { isAuthenticated, loading } = useAuth();
  const [message, setMessage] = useState("");
  const [injuries, setInjuries] = useState<string[]>([]);
  const [injuryInput, setInjuryInput] = useState("");

  const chatMutation = trpc.ai.chat.useMutation({
    onSuccess: () => {
      setMessage("");
      toast.success("Response received");
    },
    onError: (error) => {
      toast.error(`Failed to send message: ${error.message}`);
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  const handleSendMessage = () => {
    if (!message.trim()) return;

    chatMutation.mutate({
      message: message.trim(),
      injuries: injuries.length > 0 ? injuries : undefined,
    });
  };

  const handleAddInjury = () => {
    if (!injuryInput.trim()) return;
    setInjuries([...injuries, injuryInput.trim()]);
    setInjuryInput("");
  };

  const handleRemoveInjury = (index: number) => {
    setInjuries(injuries.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="bg-background border-b">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bot className="w-8 h-8 text-primary" />
              <h1 className="text-2xl font-bold">AI Fitness Coach</h1>
            </div>
            <Link href="/dashboard">
              <Button variant="outline" size="sm">Back to Dashboard</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="max-w-4xl mx-auto">
          {/* Injury/Pain Tracking */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Injury & Pain Tracking</CardTitle>
              <CardDescription>
                Tell the AI about any injuries or pain so it can recommend safe exercises
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2 mb-4">
                <Input
                  placeholder="e.g., knee pain, lower back injury"
                  value={injuryInput}
                  onChange={(e) => setInjuryInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleAddInjury();
                    }
                  }}
                />
                <Button onClick={handleAddInjury}>Add</Button>
              </div>
              {injuries.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {injuries.map((injury, index) => (
                    <div
                      key={index}
                      className="bg-destructive/10 text-destructive px-3 py-1 rounded-full text-sm flex items-center gap-2"
                    >
                      {injury}
                      <button
                        onClick={() => handleRemoveInjury(index)}
                        className="hover:text-destructive-foreground"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Chat Interface */}
          <Card className="flex flex-col h-[600px]">
            <CardHeader>
              <CardTitle>Chat with Your AI Coach</CardTitle>
              <CardDescription>
                Ask about nutrition, workouts, or get personalized advice based on your scan data
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              {/* Messages */}
              <div className="flex-1 overflow-y-auto space-y-4 mb-4 p-4 bg-muted/30 rounded-lg">
                {/* Welcome Message */}
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-background p-3 rounded-lg border">
                      <p className="text-sm">
                        Hi! I'm your AI fitness coach. I can help you with:
                      </p>
                      <ul className="text-sm mt-2 space-y-1 list-disc list-inside text-muted-foreground">
                        <li>Personalized workout advice based on your body scan results</li>
                        <li>Nutrition guidance tailored to your goals</li>
                        <li>Exercise modifications for injuries or pain</li>
                        <li>Motivation and accountability</li>
                      </ul>
                      <p className="text-sm mt-2">
                        What would you like to know?
                      </p>
                    </div>
                  </div>
                </div>

                {/* Chat History would go here */}
                {chatMutation.data && (
                  <>
                    <div className="flex gap-3 justify-end">
                      <div className="flex-1 max-w-[80%]">
                        <div className="bg-primary text-primary-foreground p-3 rounded-lg">
                          <p className="text-sm">{message}</p>
                        </div>
                      </div>
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                        <User className="w-5 h-5" />
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                        <Bot className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <div className="bg-background p-3 rounded-lg border prose prose-sm max-w-none">
                          <Streamdown>{chatMutation.data.message}</Streamdown>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {chatMutation.isPending && (
                  <div className="flex gap-3">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                      <Bot className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className="bg-background p-3 rounded-lg border">
                        <div className="flex gap-1">
                          <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
                          <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></div>
                          <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="flex gap-2">
                <Input
                  placeholder="Ask me anything about fitness, nutrition, or your progress..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  disabled={chatMutation.isPending}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!message.trim() || chatMutation.isPending}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Example Questions */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Example Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  className="justify-start h-auto py-3 px-4"
                  onClick={() => setMessage("I have knee pain. What exercises should I avoid?")}
                >
                  <span className="text-left text-sm">
                    I have knee pain. What exercises should I avoid?
                  </span>
                </Button>
                <Button
                  variant="outline"
                  className="justify-start h-auto py-3 px-4"
                  onClick={() => setMessage("What should I eat to build muscle?")}
                >
                  <span className="text-left text-sm">
                    What should I eat to build muscle?
                  </span>
                </Button>
                <Button
                  variant="outline"
                  className="justify-start h-auto py-3 px-4"
                  onClick={() => setMessage("How can I target my waist area?")}
                >
                  <span className="text-left text-sm">
                    How can I target my waist area?
                  </span>
                </Button>
                <Button
                  variant="outline"
                  className="justify-start h-auto py-3 px-4"
                  onClick={() => setMessage("What's a good post-workout meal?")}
                >
                  <span className="text-left text-sm">
                    What's a good post-workout meal?
                  </span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

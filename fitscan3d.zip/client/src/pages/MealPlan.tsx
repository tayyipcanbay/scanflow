import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { 
  UtensilsCrossed, Sparkles, ArrowLeft, Flame, Apple, Beef, 
  Wheat, Droplets, Clock, Calendar, ChevronRight, Loader2,
  Coffee, Sun, Moon, Cookie, TrendingUp, Target, Salad
} from "lucide-react";
import { useState } from "react";
import { Link, Redirect, useLocation } from "wouter";
import { toast } from "sonner";

// Meal type icons and colors
const mealTypeStyles: Record<string, { icon: any; bg: string; gradient: string }> = {
  Breakfast: { icon: Coffee, bg: "bg-amber-100", gradient: "from-amber-400 to-orange-400" },
  Lunch: { icon: Sun, bg: "bg-green-100", gradient: "from-green-400 to-emerald-400" },
  Dinner: { icon: Moon, bg: "bg-indigo-100", gradient: "from-indigo-400 to-purple-400" },
  Snacks: { icon: Cookie, bg: "bg-pink-100", gradient: "from-pink-400 to-rose-400" },
  Snack: { icon: Cookie, bg: "bg-pink-100", gradient: "from-pink-400 to-rose-400" },
};

// Day colors for visual variety
const dayColors = [
  "from-blue-500 to-cyan-500",
  "from-purple-500 to-pink-500",
  "from-green-500 to-teal-500",
  "from-orange-500 to-red-500",
  "from-indigo-500 to-purple-500",
  "from-rose-500 to-pink-500",
  "from-emerald-500 to-green-500",
];

export default function MealPlan() {
  const { isAuthenticated, loading } = useAuth();
  const utils = trpc.useUtils();
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1]);
  const comparisonId = searchParams.get('comparisonId');
  const [selectedDay, setSelectedDay] = useState(0);

  const { data: mealPlans, isLoading, refetch } = trpc.ai.getMealPlans.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const generateMutation = trpc.ai.generateMealPlan.useMutation({
    onSuccess: () => {
      toast.success("🎉 Meal plan generated successfully!");
      utils.ai.getMealPlans.invalidate();
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Failed to generate meal plan: ${error.message}`);
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 via-white to-emerald-50">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-green-600 mx-auto" />
          <p className="mt-4 text-muted-foreground">Loading your nutrition plan...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  const handleGenerate = () => {
    generateMutation.mutate({
      comparisonId: comparisonId ? parseInt(comparisonId) : undefined,
    });
  };

  // Get the latest meal plan
  const latestPlan = mealPlans?.[0];
  let weeklyPlan: any = null;
  let aiInsights: string[] = [];

  if (latestPlan?.planData) {
    try {
      const parsed = typeof latestPlan.planData === 'string' 
        ? JSON.parse(latestPlan.planData) 
        : latestPlan.planData;
      weeklyPlan = parsed;
      aiInsights = parsed.tips || [];
    } catch (e) {
      console.error('Failed to parse meal plan data:', e);
    }
  }

  const currentDayMeals = weeklyPlan?.days?.[selectedDay]?.meals || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      {/* Colorful Header */}
      <header className="bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 text-white">
        <div className="container py-6">
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="mb-4 text-white/80 hover:text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <UtensilsCrossed className="w-10 h-10" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">AI Meal Plan</h1>
              <p className="text-white/80">Personalized nutrition based on your goals</p>
            </div>
          </div>
          
          {/* Stats Bar */}
          {weeklyPlan && (
            <div className="flex gap-6 mt-6">
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-300" />
                <span className="font-semibold">{latestPlan?.dailyCalories || Math.round((weeklyPlan.weeklyCalories || 14000) / 7)} kcal/day</span>
              </div>
              <div className="flex items-center gap-2">
                <Beef className="w-5 h-5 text-red-300" />
                <span className="font-semibold">{weeklyPlan.macros?.protein || 0}g protein</span>
              </div>
              <div className="flex items-center gap-2">
                <Wheat className="w-5 h-5 text-amber-300" />
                <span className="font-semibold">{weeklyPlan.macros?.carbs || 0}g carbs</span>
              </div>
              <div className="flex items-center gap-2">
                <Droplets className="w-5 h-5 text-yellow-300" />
                <span className="font-semibold">{weeklyPlan.macros?.fats || 0}g fats</span>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="max-w-6xl mx-auto space-y-8">
          {/* Generate Button */}
          <Card className="border-2 border-dashed border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-green-100 rounded-xl">
                    <Salad className="w-8 h-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-green-900">
                      {weeklyPlan ? 'Regenerate Your Plan' : 'Create Your Meal Plan'}
                    </h3>
                    <p className="text-green-700 text-sm">
                      AI-powered nutrition tailored to your body composition
                    </p>
                  </div>
                </div>
                <Button
                  onClick={handleGenerate}
                  disabled={generateMutation.isPending}
                  className="h-12 px-6 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                >
                  {generateMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      {weeklyPlan ? 'Regenerate' : 'Generate'} Plan
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Meal Plan Display */}
          {isLoading ? (
            <div className="text-center py-12">
              <Loader2 className="w-12 h-12 animate-spin text-green-600 mx-auto" />
              <p className="mt-4 text-muted-foreground">Loading meal plan...</p>
            </div>
          ) : weeklyPlan ? (
            <div className="space-y-6">
              {/* Day Selector */}
              <div className="flex gap-2 overflow-x-auto pb-2">
                {weeklyPlan.days?.map((day: any, index: number) => (
                  <button
                    key={index}
                    onClick={() => setSelectedDay(index)}
                    className={`flex-shrink-0 px-6 py-3 rounded-xl font-semibold transition-all ${
                      selectedDay === index
                        ? `bg-gradient-to-r ${dayColors[index % dayColors.length]} text-white shadow-lg scale-105`
                        : 'bg-white text-gray-600 hover:bg-gray-50 border'
                    }`}
                  >
                    <Calendar className="w-4 h-4 inline mr-2" />
                    {day.day}
                  </button>
                ))}
              </div>

              {/* Selected Day Meals */}
              <div className="grid md:grid-cols-2 gap-6">
                {currentDayMeals.map((meal: any, index: number) => {
                  const style = mealTypeStyles[meal.type] || mealTypeStyles.Snacks;
                  const Icon = style.icon;
                  
                  return (
                    <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                      <div className={`h-2 bg-gradient-to-r ${style.gradient}`} />
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`p-2 ${style.bg} rounded-lg`}>
                              <Icon className="w-5 h-5 text-gray-700" />
                            </div>
                            <div>
                              <CardTitle className="text-lg">{meal.type}</CardTitle>
                              <CardDescription className="font-medium text-gray-900">
                                {meal.name}
                              </CardDescription>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-2xl font-bold text-gray-900">{meal.calories}</span>
                            <span className="text-sm text-gray-500 ml-1">kcal</span>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">{meal.description}</p>
                        
                        {/* Macro Badges */}
                        <div className="flex gap-2">
                          <div className="flex items-center gap-1 bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium">
                            <Beef className="w-3 h-3" />
                            {meal.protein}g
                          </div>
                          <div className="flex items-center gap-1 bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-sm font-medium">
                            <Wheat className="w-3 h-3" />
                            {meal.carbs}g
                          </div>
                          <div className="flex items-center gap-1 bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-medium">
                            <Droplets className="w-3 h-3" />
                            {meal.fats}g
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Daily Summary */}
              <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Target className="w-8 h-8 text-blue-600" />
                      <div>
                        <h3 className="font-bold text-blue-900">Daily Total</h3>
                        <p className="text-blue-700 text-sm">{weeklyPlan.days?.[selectedDay]?.day}</p>
                      </div>
                    </div>
                    <div className="flex gap-8">
                      <div className="text-center">
                        <p className="text-3xl font-bold text-blue-900">
                          {currentDayMeals.reduce((sum: number, m: any) => sum + (m.calories || 0), 0)}
                        </p>
                        <p className="text-sm text-blue-600">Calories</p>
                      </div>
                      <div className="text-center">
                        <p className="text-3xl font-bold text-red-600">
                          {currentDayMeals.reduce((sum: number, m: any) => sum + (m.protein || 0), 0)}g
                        </p>
                        <p className="text-sm text-gray-600">Protein</p>
                      </div>
                      <div className="text-center">
                        <p className="text-3xl font-bold text-amber-600">
                          {currentDayMeals.reduce((sum: number, m: any) => sum + (m.carbs || 0), 0)}g
                        </p>
                        <p className="text-sm text-gray-600">Carbs</p>
                      </div>
                      <div className="text-center">
                        <p className="text-3xl font-bold text-yellow-600">
                          {currentDayMeals.reduce((sum: number, m: any) => sum + (m.fats || 0), 0)}g
                        </p>
                        <p className="text-sm text-gray-600">Fats</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* AI Tips */}
              {aiInsights.length > 0 && (
                <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <TrendingUp className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <CardTitle className="text-purple-900">Nutrition Tips</CardTitle>
                        <CardDescription className="text-purple-700">
                          AI recommendations for your goals
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-3">
                      {aiInsights.map((tip: string, index: number) => (
                        <div key={index} className="flex items-start gap-3 p-3 bg-white/60 rounded-lg">
                          <span className="text-lg">💡</span>
                          <p className="text-sm text-purple-800">{tip}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            /* Empty State */
            <Card className="text-center py-16 bg-gradient-to-br from-gray-50 to-slate-100">
              <CardContent>
                <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-green-100 to-emerald-100 rounded-full flex items-center justify-center">
                  <UtensilsCrossed className="w-12 h-12 text-green-500" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">No Meal Plan Yet</h2>
                <p className="text-gray-600 mb-8 max-w-md mx-auto">
                  Generate your personalized AI meal plan based on your fitness goals and body composition
                </p>
                <Button
                  onClick={handleGenerate}
                  disabled={generateMutation.isPending}
                  size="lg"
                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                >
                  {generateMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Generate Meal Plan
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

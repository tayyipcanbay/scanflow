import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link, Redirect, useLocation } from "wouter";
import { Activity, Scale, Ruler, Target, User, ArrowRight, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function Register() {
  const { isAuthenticated, user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    age: "",
    weight: "",
    height: "",
    gender: "",
    activityLevel: "",
    fitnessGoal: "",
  });

  const utils = trpc.useUtils();
  const saveProfile = trpc.profile.update.useMutation({
    onSuccess: () => {
      toast.success("Profile saved successfully!");
      utils.profile.get.invalidate();
      setLocation("/dashboard");
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to save profile");
    },
  });

  const { data: existingProfile } = trpc.profile.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // If not authenticated, show login prompt
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <User className="w-8 h-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">Welcome to FitScan3D</CardTitle>
            <CardDescription>
              Sign in to create your fitness profile and start tracking your body transformation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <a href={getLoginUrl()}>
              <Button className="w-full h-12 text-lg" size="lg">
                Sign In to Get Started
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </a>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If already has profile, redirect to dashboard
  if (existingProfile) {
    return <Redirect to="/dashboard" />;
  }

  const handleSubmit = () => {
    if (!formData.age || !formData.weight || !formData.height || !formData.gender || !formData.activityLevel || !formData.fitnessGoal) {
      toast.error("Please fill in all fields");
      return;
    }

    const profileData = {
      age: parseInt(formData.age),
      weight: parseFloat(formData.weight),
      height: parseFloat(formData.height),
      gender: formData.gender as "male" | "female" | "other",
      activityLevel: formData.activityLevel as "sedentary" | "light" | "moderate" | "active" | "very_active",
      fitnessGoal: formData.fitnessGoal as "bulking" | "cutting" | "maintaining" | "recomp",
    };

    saveProfile.mutate(profileData);
  };

  const isStepComplete = (stepNum: number) => {
    switch (stepNum) {
      case 1:
        return formData.age && formData.gender;
      case 2:
        return formData.height && formData.weight;
      case 3:
        return formData.activityLevel && formData.fitnessGoal;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Complete Your Profile</h1>
          <p className="text-gray-600 mt-2">
            Welcome, {user?.name || "User"}! Let's set up your fitness profile.
          </p>
        </div>

        {/* Progress Steps */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center gap-2">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
                    step === s
                      ? "bg-primary text-white"
                      : isStepComplete(s)
                      ? "bg-green-500 text-white"
                      : "bg-gray-200 text-gray-500"
                  }`}
                >
                  {isStepComplete(s) && step !== s ? <CheckCircle className="w-5 h-5" /> : s}
                </div>
                {s < 3 && (
                  <div className={`w-12 h-1 mx-1 ${isStepComplete(s) ? "bg-green-500" : "bg-gray-200"}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Form Card */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {step === 1 && <><User className="w-5 h-5" /> Basic Information</>}
              {step === 2 && <><Ruler className="w-5 h-5" /> Body Measurements</>}
              {step === 3 && <><Target className="w-5 h-5" /> Fitness Goals</>}
            </CardTitle>
            <CardDescription>
              {step === 1 && "Tell us about yourself"}
              {step === 2 && "Enter your current measurements"}
              {step === 3 && "Set your fitness objectives"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 1: Basic Info */}
            {step === 1 && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                    min="13"
                    max="100"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select
                    value={formData.gender}
                    onValueChange={(value) => setFormData({ ...formData, gender: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {/* Step 2: Measurements */}
            {step === 2 && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="height" className="flex items-center gap-2">
                    <Ruler className="w-4 h-4" /> Height (cm)
                  </Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="e.g., 175"
                    value={formData.height}
                    onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                    min="100"
                    max="250"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight" className="flex items-center gap-2">
                    <Scale className="w-4 h-4" /> Weight (kg)
                  </Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 70"
                    value={formData.weight}
                    onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                    min="30"
                    max="300"
                    step="0.1"
                  />
                </div>
              </>
            )}

            {/* Step 3: Goals */}
            {step === 3 && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="activityLevel" className="flex items-center gap-2">
                    <Activity className="w-4 h-4" /> Activity Level
                  </Label>
                  <Select
                    value={formData.activityLevel}
                    onValueChange={(value) => setFormData({ ...formData, activityLevel: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                      <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                      <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                      <SelectItem value="active">Active (6-7 days/week)</SelectItem>
                      <SelectItem value="very_active">Very Active (twice daily)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fitnessGoal" className="flex items-center gap-2">
                    <Target className="w-4 h-4" /> Fitness Goal
                  </Label>
                  <Select
                    value={formData.fitnessGoal}
                    onValueChange={(value) => setFormData({ ...formData, fitnessGoal: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your goal" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bulking">Bulking (Build Muscle)</SelectItem>
                      <SelectItem value="cutting">Cutting (Lose Fat)</SelectItem>
                      <SelectItem value="maintaining">Maintaining (Stay Same)</SelectItem>
                      <SelectItem value="recomp">Recomposition (Lose Fat & Gain Muscle)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-4">
              {step > 1 ? (
                <Button variant="outline" onClick={() => setStep(step - 1)}>
                  Back
                </Button>
              ) : (
                <div />
              )}
              
              {step < 3 ? (
                <Button
                  onClick={() => setStep(step + 1)}
                  disabled={!isStepComplete(step)}
                >
                  Continue
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={!isStepComplete(3) || saveProfile.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {saveProfile.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Creating...
                    </>
                  ) : (
                    <>
                      Complete Setup
                      <CheckCircle className="ml-2 w-4 h-4" />
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Skip link */}
        <div className="text-center mt-4">
          <Link href="/dashboard">
            <Button variant="link" className="text-gray-500">
              Skip for now
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Chat from "./pages/Chat";
import Upload from "./pages/Upload";
import Profile from "./pages/Profile";
import Scans from "./pages/Scans";
import Compare from "./pages/Compare";
import ComparisonDetail from "./pages/ComparisonDetail";
import MealPlan from "./pages/MealPlan";
import Exercises from "./pages/Exercises";
import Register from "./pages/Register";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/chat"} component={Chat} />
      <Route path={"/upload"} component={Upload} />
      <Route path={"/profile"} component={Profile} />
      <Route path={"/scans"} component={Scans} />
      <Route path={"/compare"} component={Compare} />
      <Route path={"/comparison/:id"} component={ComparisonDetail} />
      <Route path={"/meal-plan"} component={MealPlan} />
      <Route path={"/exercises"} component={Exercises} />
      <Route path={"/register"} component={Register} />
      <Route path={"/get-started"} component={Register} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// Fitness app with modern, energetic design
// Using light theme with vibrant accent colors

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("profile.get", () => {
  it("returns undefined for user without profile", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.profile.get();

    expect(result).toBeUndefined();
  });
});

describe("profile.update", () => {
  it("creates a new profile with valid data", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const profileData = {
      height: 180,
      weight: 75,
      age: 30,
      gender: "male" as const,
      fitnessGoal: "maintaining" as const,
      activityLevel: "moderate" as const,
    };

    const result = await caller.profile.update(profileData);

    expect(result).toBeDefined();
    expect(result?.height).toBe(180);
    expect(result?.weight).toBe(75);
    expect(result?.age).toBe(30);
    expect(result?.gender).toBe("male");
    expect(result?.fitnessGoal).toBe("maintaining");
    expect(result?.activityLevel).toBe("moderate");
  });

  it("updates existing profile", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create initial profile
    await caller.profile.update({
      height: 180,
      weight: 75,
      age: 30,
    });

    // Update profile
    const result = await caller.profile.update({
      weight: 80,
      fitnessGoal: "bulking" as const,
    });

    expect(result).toBeDefined();
    expect(result?.weight).toBe(80);
    expect(result?.fitnessGoal).toBe("bulking");
  });
});

describe("scans.list", () => {
  it("returns empty array for user with no scans", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.scans.list();

    expect(result).toEqual([]);
  });
});

describe("comparisons.list", () => {
  it("returns empty array for user with no comparisons", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.comparisons.list();

    expect(result).toEqual([]);
  });
});

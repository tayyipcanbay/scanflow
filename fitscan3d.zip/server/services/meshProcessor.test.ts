import { describe, expect, it } from "vitest";
import { parseMeshData, compareMeshes } from "./meshProcessor";

describe("parseMeshData", () => {
  it("parses simple OBJ file correctly", () => {
    const objContent = `
v 0.0 0.0 0.0
v 1.0 0.0 0.0
v 0.0 1.0 0.0
f 1 2 3
    `.trim();

    const result = parseMeshData(objContent, "obj");

    expect(result.vertices).toHaveLength(3);
    expect(result.faces).toHaveLength(1);
    expect(result.vertexCount).toBe(3);
    expect(result.vertices[0]).toEqual([0, 0, 0]);
    expect(result.vertices[1]).toEqual([1, 0, 0]);
    expect(result.vertices[2]).toEqual([0, 1, 0]);
    expect(result.faces[0]).toEqual([0, 1, 2]);
  });

  it("calculates volume for simple mesh", () => {
    const objContent = `
v 0.0 0.0 0.0
v 1.0 0.0 0.0
v 0.0 1.0 0.0
v 0.0 0.0 1.0
f 1 2 3
f 1 2 4
f 1 3 4
f 2 3 4
    `.trim();

    const result = parseMeshData(objContent, "obj");

    expect(result.volume).toBeGreaterThan(0);
    expect(result.surfaceArea).toBeGreaterThan(0);
  });

  it("handles empty OBJ file", () => {
    const objContent = "";

    const result = parseMeshData(objContent, "obj");

    expect(result.vertices).toHaveLength(0);
    expect(result.faces).toHaveLength(0);
    expect(result.vertexCount).toBe(0);
  });
});

describe("compareMeshes", () => {
  it("detects no change between identical meshes", () => {
    const meshData = {
      vertices: [
        [0, 0, 0],
        [1, 0, 0],
        [0, 1, 0],
      ],
      faces: [[0, 1, 2]],
      vertexCount: 3,
      volume: 0.1,
      surfaceArea: 1.0,
    };

    const result = compareMeshes(meshData, meshData, {
      height: 180,
      weight: 75,
      age: 30,
      gender: "male",
    });

    expect(result.overallVolumeChange).toBe(0);
    expect(result.regions).toBeDefined();
    expect(result.colorMapData).toBeDefined();
  });

  it("throws error for meshes with different vertex counts", () => {
    const mesh1 = {
      vertices: [[0, 0, 0], [1, 0, 0]],
      faces: [[0, 1]],
      vertexCount: 2,
      volume: 0.1,
      surfaceArea: 1.0,
    };

    const mesh2 = {
      vertices: [[0, 0, 0], [1, 0, 0], [0, 1, 0]],
      faces: [[0, 1, 2]],
      vertexCount: 3,
      volume: 0.1,
      surfaceArea: 1.0,
    };

    expect(() => {
      compareMeshes(mesh1, mesh2, {});
    }).toThrow("Meshes must have the same topology for comparison");
  });

  it("calculates body fat percentage based on user profile", () => {
    const meshData = {
      vertices: [[0, 0, 0]],
      faces: [],
      vertexCount: 1,
      volume: 0.1,
      surfaceArea: 1.0,
    };

    const result = compareMeshes(meshData, meshData, {
      height: 180,
      weight: 75,
      age: 30,
      gender: "male",
    });

    expect(result.bodyFatPercentage).toBeGreaterThan(0);
    expect(result.bodyFatPercentage).toBeLessThan(5000); // Less than 50%
  });

  it("generates color map data for visualization", () => {
    const meshData = {
      vertices: [
        [0, 0, 0],
        [1, 0, 0],
        [0, 1, 0],
      ],
      faces: [[0, 1, 2]],
      vertexCount: 3,
      volume: 0.1,
      surfaceArea: 1.0,
    };

    const result = compareMeshes(meshData, meshData, {});

    expect(result.colorMapData).toHaveLength(3);
    expect(result.colorMapData[0]).toHaveProperty("vertexIndex");
    expect(result.colorMapData[0]).toHaveProperty("color");
    expect(result.colorMapData[0]).toHaveProperty("magnitude");
    expect(result.colorMapData[0].color).toHaveLength(3);
  });
});

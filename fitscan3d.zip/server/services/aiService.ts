import { invokeLLM } from '../_core/llm';

export interface MealPlanRequest {
  fitnessGoal: 'bulking' | 'cutting' | 'maintaining' | 'recomp';
  dailyCalories: number;
  bodyFatPercentage?: number;
  muscleMassChange?: number;
  fatMassChange?: number;
  dietaryRestrictions?: string[];
}

export interface ExerciseRecommendationRequest {
  regions: {
    name: string;
    changeType: 'increase' | 'decrease' | 'stable';
    volumeChange: number;
  }[];
  fitnessGoal: 'bulking' | 'cutting' | 'maintaining' | 'recomp';
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
  injuries?: string[];
}

export interface ChatRequest {
  message: string;
  userContext: {
    fitnessGoal?: string;
    recentComparison?: {
      bodyFatPercentage?: number;
      muscleMassChange?: number;
      fatMassChange?: number;
      regions?: any[];
    };
    injuries?: string[];
  };
  chatHistory: { role: 'user' | 'assistant'; content: string }[];
}

/**
 * Generate a weekly meal plan based on user goals and body composition
 */
export async function generateMealPlan(request: MealPlanRequest) {
  const prompt = `You are a professional nutritionist and fitness coach. Generate a detailed weekly meal plan based on the following:

**User Goal**: ${request.fitnessGoal}
**Daily Calorie Target**: ${request.dailyCalories} kcal
${request.bodyFatPercentage ? `**Current Body Fat**: ${(request.bodyFatPercentage / 100).toFixed(1)}%` : ''}
${request.muscleMassChange ? `**Recent Muscle Mass Change**: ${(request.muscleMassChange / 1000).toFixed(2)} kg` : ''}
${request.fatMassChange ? `**Recent Fat Mass Change**: ${(request.fatMassChange / 1000).toFixed(2)} kg` : ''}
${request.dietaryRestrictions?.length ? `**Dietary Restrictions**: ${request.dietaryRestrictions.join(', ')}` : ''}

Generate a complete 7-day meal plan with:
1. Daily breakdown (Monday-Sunday)
2. Meals for each day: Breakfast, Lunch, Dinner, Snacks
3. Approximate calories and macros (protein, carbs, fats) for each meal
4. Simple, practical meal suggestions

Format as JSON with this structure:
{
  "weeklyCalories": number,
  "macros": { "protein": number, "carbs": number, "fats": number },
  "days": [
    {
      "day": "Monday",
      "meals": [
        {
          "type": "Breakfast",
          "name": "Meal name",
          "calories": number,
          "protein": number,
          "carbs": number,
          "fats": number,
          "description": "Brief description"
        }
      ]
    }
  ],
  "tips": ["Tip 1", "Tip 2"]
}`;

  const response = await invokeLLM({
    messages: [
      { role: 'system', content: 'You are a professional nutritionist. Always respond with valid JSON.' },
      { role: 'user', content: prompt },
    ],
    response_format: {
      type: 'json_schema',
      json_schema: {
        name: 'meal_plan',
        strict: true,
        schema: {
          type: 'object',
          properties: {
            weeklyCalories: { type: 'number' },
            macros: {
              type: 'object',
              properties: {
                protein: { type: 'number' },
                carbs: { type: 'number' },
                fats: { type: 'number' },
              },
              required: ['protein', 'carbs', 'fats'],
              additionalProperties: false,
            },
            days: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  day: { type: 'string' },
                  meals: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        type: { type: 'string' },
                        name: { type: 'string' },
                        calories: { type: 'number' },
                        protein: { type: 'number' },
                        carbs: { type: 'number' },
                        fats: { type: 'number' },
                        description: { type: 'string' },
                      },
                      required: ['type', 'name', 'calories', 'protein', 'carbs', 'fats', 'description'],
                      additionalProperties: false,
                    },
                  },
                },
                required: ['day', 'meals'],
                additionalProperties: false,
              },
            },
            tips: {
              type: 'array',
              items: { type: 'string' },
            },
          },
          required: ['weeklyCalories', 'macros', 'days', 'tips'],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content;
  if (!content) throw new Error('Failed to generate meal plan');

  const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
  return JSON.parse(contentStr);
}

/**
 * Generate exercise recommendations based on body region analysis
 */
export async function generateExerciseRecommendations(request: ExerciseRecommendationRequest) {
  const regionSummary = request.regions
    .map(r => `- ${r.name}: ${r.changeType} (${(r.volumeChange / 1000).toFixed(2)} cm³)`)
    .join('\n');

  const injuryWarning = request.injuries?.length
    ? `\n**IMPORTANT**: User has reported: ${request.injuries.join(', ')}. Avoid exercises that may aggravate these conditions.`
    : '';

  const prompt = `You are a certified personal trainer. Generate targeted exercise recommendations based on body scan analysis.

**Fitness Goal**: ${request.fitnessGoal}
**Activity Level**: ${request.activityLevel}

**Body Region Analysis**:
${regionSummary}
${injuryWarning}

Generate 8-12 exercises with:
1. Target the regions that need improvement
2. Consider the user's fitness goal
3. Include sets, reps, and intensity
4. Provide brief descriptions
5. **AVOID exercises that may worsen reported injuries**

Format as JSON array:
[
  {
    "name": "Exercise name",
    "targetRegion": "waist|chest|arms|thighs|hips|shoulders|calves|full_body",
    "sets": 3,
    "reps": "10-12",
    "intensity": "low|moderate|high",
    "description": "How to perform and why it helps",
    "modifications": "Easier/harder variations"
  }
]`;

  const response = await invokeLLM({
    messages: [
      { role: 'system', content: 'You are a certified personal trainer. Always respond with valid JSON array.' },
      { role: 'user', content: prompt },
    ],
  });

  const content = response.choices[0]?.message?.content;
  if (!content) throw new Error('Failed to generate exercise recommendations');

  const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
  // Extract JSON from response
  const jsonMatch = contentStr.match(/\[[\s\S]*\]/);
  if (!jsonMatch) throw new Error('Invalid response format');

  return JSON.parse(jsonMatch[0]);
}

/**
 * AI chatbot for personalized fitness guidance
 */
export async function chatWithAI(request: ChatRequest) {
  const contextInfo = [];
  
  if (request.userContext.fitnessGoal) {
    contextInfo.push(`User's fitness goal: ${request.userContext.fitnessGoal}`);
  }
  
  if (request.userContext.recentComparison) {
    const comp = request.userContext.recentComparison;
    contextInfo.push(`Recent body scan results:`);
    if (comp.bodyFatPercentage) {
      contextInfo.push(`- Body fat: ${(comp.bodyFatPercentage / 100).toFixed(1)}%`);
    }
    if (comp.muscleMassChange) {
      contextInfo.push(`- Muscle mass change: ${(comp.muscleMassChange / 1000).toFixed(2)} kg`);
    }
    if (comp.fatMassChange) {
      contextInfo.push(`- Fat mass change: ${(comp.fatMassChange / 1000).toFixed(2)} kg`);
    }
  }
  
  if (request.userContext.injuries?.length) {
    contextInfo.push(`User has reported: ${request.userContext.injuries.join(', ')}`);
    contextInfo.push(`**IMPORTANT**: Recommend exercises that avoid aggravating these conditions.`);
  }

  const systemPrompt = `You are an expert fitness coach and nutritionist specializing in body transformation. You help users understand their 3D body scan results, provide personalized workout and nutrition advice, and answer fitness-related questions.

${contextInfo.length > 0 ? `**User Context**:\n${contextInfo.join('\n')}` : ''}

**Guidelines**:
- Be encouraging and supportive
- Provide specific, actionable advice
- Consider the user's injuries and limitations
- Reference their body scan data when relevant
- Keep responses concise but informative
- If user mentions pain or injury, recommend safe alternatives`;

  const messages = [
    { role: 'system' as const, content: systemPrompt },
    ...request.chatHistory.map(msg => ({
      role: msg.role as 'user' | 'assistant',
      content: msg.content,
    })),
    { role: 'user' as const, content: request.message },
  ];

  const response = await invokeLLM({ messages });

  const content = response.choices[0]?.message?.content;
  if (!content) throw new Error('Failed to get chat response');

  const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
  return {
    message: contentStr,
    timestamp: new Date(),
  };
}

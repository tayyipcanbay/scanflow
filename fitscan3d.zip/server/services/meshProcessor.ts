/**
 * Mesh Processing Service
 * Handles 3D mesh analysis, body composition calculations, and region detection
 */

export interface MeshData {
  vertices: number[][];
  faces: number[][];
  vertexCount: number;
  volume: number;
  surfaceArea: number;
}

export interface BodyRegion {
  name: string;
  vertexIndices: number[];
  volumeChange: number;
  changePercentage: number;
  changeType: 'increase' | 'decrease' | 'stable';
}

export interface ComparisonResult {
  overallVolumeChange: number;
  bodyFatPercentage: number;
  muscleMassChange: number;
  fatMassChange: number;
  regions: BodyRegion[];
  colorMapData: {
    vertexIndex: number;
    color: [number, number, number];
    magnitude: number;
  }[];
}

/**
 * Parse mesh file content and extract vertex/face data
 * Supports OBJ format (most common for body scans)
 */
export function parseMeshData(fileContent: string, format: 'obj' | 'glb' | 'fbx'): MeshData {
  if (format === 'obj') {
    return parseOBJ(fileContent);
  }
  // For GLB/FBX, we'll need to handle binary formats differently
  // For now, return empty structure
  return {
    vertices: [],
    faces: [],
    vertexCount: 0,
    volume: 0,
    surfaceArea: 0,
  };
}

/**
 * Parse OBJ file format
 */
function parseOBJ(content: string): MeshData {
  const vertices: number[][] = [];
  const faces: number[][] = [];
  
  const lines = content.split('\n');
  
  for (const line of lines) {
    const trimmed = line.trim();
    
    if (trimmed.startsWith('v ')) {
      // Vertex line: v x y z
      const parts = trimmed.split(/\s+/);
      const x = parseFloat(parts[1]);
      const y = parseFloat(parts[2]);
      const z = parseFloat(parts[3]);
      vertices.push([x, y, z]);
    } else if (trimmed.startsWith('f ')) {
      // Face line: f v1 v2 v3 or f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3
      const parts = trimmed.split(/\s+/).slice(1);
      const faceIndices = parts.map(part => {
        const indices = part.split('/');
        return parseInt(indices[0]) - 1; // OBJ indices are 1-based
      });
      faces.push(faceIndices);
    }
  }
  
  const volume = calculateMeshVolume(vertices, faces);
  const surfaceArea = calculateSurfaceArea(vertices, faces);
  
  return {
    vertices,
    faces,
    vertexCount: vertices.length,
    volume,
    surfaceArea,
  };
}

/**
 * Calculate mesh volume using signed volume of tetrahedra
 */
function calculateMeshVolume(vertices: number[][], faces: number[][]): number {
  let volume = 0;
  
  for (const face of faces) {
    if (face.length < 3) continue;
    
    const v1 = vertices[face[0]];
    const v2 = vertices[face[1]];
    const v3 = vertices[face[2]];
    
    if (!v1 || !v2 || !v3) continue;
    
    // Signed volume of tetrahedron formed by origin and triangle
    volume += signedVolumeOfTriangle(v1, v2, v3);
  }
  
  return Math.abs(volume);
}

function signedVolumeOfTriangle(p1: number[], p2: number[], p3: number[]): number {
  return (
    p1[0] * p2[1] * p3[2] +
    p2[0] * p3[1] * p1[2] +
    p3[0] * p1[1] * p2[2] -
    p1[0] * p3[1] * p2[2] -
    p2[0] * p1[1] * p3[2] -
    p3[0] * p2[1] * p1[2]
  ) / 6.0;
}

/**
 * Calculate surface area of mesh
 */
function calculateSurfaceArea(vertices: number[][], faces: number[][]): number {
  let area = 0;
  
  for (const face of faces) {
    if (face.length < 3) continue;
    
    const v1 = vertices[face[0]];
    const v2 = vertices[face[1]];
    const v3 = vertices[face[2]];
    
    if (!v1 || !v2 || !v3) continue;
    
    area += triangleArea(v1, v2, v3);
  }
  
  return area;
}

function triangleArea(p1: number[], p2: number[], p3: number[]): number {
  // Using Heron's formula
  const a = distance(p1, p2);
  const b = distance(p2, p3);
  const c = distance(p3, p1);
  const s = (a + b + c) / 2;
  return Math.sqrt(s * (s - a) * (s - b) * (s - c));
}

function distance(p1: number[], p2: number[]): number {
  const dx = p2[0] - p1[0];
  const dy = p2[1] - p1[1];
  const dz = p2[2] - p1[2];
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

/**
 * Compare two meshes and calculate body changes
 */
export function compareMeshes(
  baselineMesh: MeshData,
  comparisonMesh: MeshData,
  userProfile: { height?: number; weight?: number; age?: number; gender?: string }
): ComparisonResult {
  // Ensure meshes have same vertex count (required for comparison)
  if (baselineMesh.vertexCount !== comparisonMesh.vertexCount) {
    throw new Error('Meshes must have the same topology for comparison');
  }
  
  // Calculate per-vertex displacement
  const displacements: number[] = [];
  for (let i = 0; i < baselineMesh.vertices.length; i++) {
    const v1 = baselineMesh.vertices[i];
    const v2 = comparisonMesh.vertices[i];
    const dist = distance(v1, v2);
    displacements.push(dist);
  }
  
  // Detect body regions
  const regions = detectBodyRegions(baselineMesh, displacements);
  
  // Calculate overall volume change
  const volumeChange = comparisonMesh.volume - baselineMesh.volume;
  
  // Estimate body fat percentage based on volume and user data
  const bodyFatPercentage = estimateBodyFat(comparisonMesh, userProfile);
  
  // Estimate muscle/fat mass changes
  const { muscleMassChange, fatMassChange } = estimateMassChanges(
    volumeChange,
    regions,
    userProfile
  );
  
  // Generate color map for visualization
  const colorMapData = generateColorMap(displacements);
  
  return {
    overallVolumeChange: Math.round(volumeChange * 1000), // Store as integer (cubic cm)
    bodyFatPercentage: Math.round(bodyFatPercentage * 100), // Store as integer (basis points)
    muscleMassChange: Math.round(muscleMassChange * 1000),
    fatMassChange: Math.round(fatMassChange * 1000),
    regions,
    colorMapData,
  };
}

/**
 * Detect body regions based on vertex positions
 */
function detectBodyRegions(mesh: MeshData, displacements: number[]): BodyRegion[] {
  const regions: BodyRegion[] = [];
  
  // Simple region detection based on Y-axis (height) and X/Z position
  const regionMap = new Map<string, number[]>();
  
  for (let i = 0; i < mesh.vertices.length; i++) {
    const vertex = mesh.vertices[i];
    const y = vertex[1]; // Height
    const x = vertex[0];
    const z = vertex[2];
    
    let regionName = 'other';
    
    // Rough body region classification (simplified)
    if (y > 1.2) {
      regionName = 'chest';
    } else if (y > 0.8 && y <= 1.2) {
      if (Math.abs(x) > 0.3) {
        regionName = 'arms';
      } else {
        regionName = 'waist';
      }
    } else if (y > 0.4 && y <= 0.8) {
      regionName = 'hips';
    } else if (y <= 0.4) {
      if (y > 0.2) {
        regionName = 'thighs';
      } else {
        regionName = 'calves';
      }
    }
    
    if (!regionMap.has(regionName)) {
      regionMap.set(regionName, []);
    }
    regionMap.get(regionName)!.push(i);
  }
  
  // Calculate statistics for each region
  for (const [regionName, indices] of Array.from(regionMap.entries())) {
    const regionDisplacements = indices.map((i: number) => displacements[i]);
    const avgDisplacement = regionDisplacements.reduce((a: number, b: number) => a + b, 0) / regionDisplacements.length;
    
    // Determine change type
    let changeType: 'increase' | 'decrease' | 'stable' = 'stable';
    if (avgDisplacement > 0.01) {
      changeType = 'increase';
    } else if (avgDisplacement < -0.01) {
      changeType = 'decrease';
    }
    
    regions.push({
      name: regionName,
      vertexIndices: indices,
      volumeChange: Math.round(avgDisplacement * 1000),
      changePercentage: Math.round(avgDisplacement * 10000),
      changeType,
    });
  }
  
  return regions;
}

/**
 * Estimate body fat percentage based on mesh volume and anthropometric data
 */
function estimateBodyFat(
  mesh: MeshData,
  userProfile: { height?: number; weight?: number; age?: number; gender?: string }
): number {
  // Simplified body fat estimation
  // In production, this would use more sophisticated algorithms
  
  if (!userProfile.weight || !userProfile.height) {
    return 0.20; // Default 20%
  }
  
  // Calculate BMI
  const heightM = userProfile.height / 100;
  const bmi = userProfile.weight / (heightM * heightM);
  
  // Rough body fat estimation from BMI
  // These are simplified formulas
  let bodyFat = 0;
  if (userProfile.gender === 'male') {
    bodyFat = 1.20 * bmi + 0.23 * (userProfile.age ?? 30) - 16.2;
  } else {
    bodyFat = 1.20 * bmi + 0.23 * (userProfile.age ?? 30) - 5.4;
  }
  
  // Clamp between 5% and 50%
  return Math.max(0.05, Math.min(0.50, bodyFat / 100));
}

/**
 * Estimate muscle and fat mass changes
 */
function estimateMassChanges(
  volumeChange: number,
  regions: BodyRegion[],
  userProfile: { weight?: number }
): { muscleMassChange: number; fatMassChange: number } {
  // Simplified estimation
  // Positive volume in muscle regions = muscle gain
  // Negative volume in fat-prone regions = fat loss
  
  const muscleRegions = ['chest', 'arms', 'shoulders'];
  const fatRegions = ['waist', 'hips'];
  
  let muscleVolumeChange = 0;
  let fatVolumeChange = 0;
  
  for (const region of regions) {
    if (muscleRegions.includes(region.name) && region.changeType === 'increase') {
      muscleVolumeChange += region.volumeChange;
    }
    if (fatRegions.includes(region.name) && region.changeType === 'decrease') {
      fatVolumeChange += Math.abs(region.volumeChange);
    }
  }
  
  // Convert volume to mass (rough approximation)
  // Muscle density ~1.06 kg/L, Fat density ~0.9 kg/L
  const muscleMassChange = (muscleVolumeChange / 1000) * 1.06;
  const fatMassChange = -(fatVolumeChange / 1000) * 0.9;
  
  return { muscleMassChange, fatMassChange };
}

/**
 * Generate color map for vertex visualization
 * Red = increase (muscle gain), Blue/Green = decrease (fat loss), White = no change
 */
function generateColorMap(displacements: number[]): {
  vertexIndex: number;
  color: [number, number, number];
  magnitude: number;
}[] {
  const maxDisplacement = Math.max(...displacements.map(Math.abs));
  
  return displacements.map((displacement, index) => {
    const normalized = displacement / maxDisplacement;
    let color: [number, number, number];
    
    if (normalized > 0.05) {
      // Increase (muscle gain) - Red
      const intensity = Math.min(1, normalized * 2);
      color = [255, Math.round((1 - intensity) * 255), Math.round((1 - intensity) * 255)];
    } else if (normalized < -0.05) {
      // Decrease (fat loss) - Blue/Green
      const intensity = Math.min(1, Math.abs(normalized) * 2);
      color = [Math.round((1 - intensity) * 255), Math.round(255 * 0.7), Math.round(255 * intensity)];
    } else {
      // No significant change - White
      color = [255, 255, 255];
    }
    
    return {
      vertexIndex: index,
      color,
      magnitude: Math.round(Math.abs(displacement) * 1000),
    };
  });
}

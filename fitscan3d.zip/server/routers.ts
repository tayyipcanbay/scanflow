import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";

// Helper function to calculate Basal Metabolic Rate
function calculateBMR(weight: number, height: number, age: number, gender: string): number {
  // Mifflin-St Jeor Equation
  if (gender === 'male') {
    return 10 * weight + 6.25 * height - 5 * age + 5;
  } else {
    return 10 * weight + 6.25 * height - 5 * age - 161;
  }
}

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Body scan and analysis routers
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const { getUserProfile } = await import('./db');
      return getUserProfile(ctx.user.id);
    }),
    update: protectedProcedure
      .input(z.object({
        height: z.number().optional(),
        weight: z.number().optional(),
        age: z.number().optional(),
        gender: z.enum(['male', 'female', 'other']).optional(),
        fitnessGoal: z.enum(['bulking', 'cutting', 'maintaining', 'recomp']).optional(),
        activityLevel: z.enum(['sedentary', 'light', 'moderate', 'active', 'very_active']).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { createOrUpdateUserProfile } = await import('./db');
        return createOrUpdateUserProfile({
          userId: ctx.user.id,
          ...input,
        });
      }),
  }),

  scans: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const { getUserScans } = await import('./db');
      return getUserScans(ctx.user.id);
    }),
    upload: protectedProcedure
      .input(z.object({
        fileName: z.string(),
        fileFormat: z.enum(['obj', 'glb', 'fbx']),
        fileSize: z.number(),
        scanDate: z.date(),
        fileContent: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { storagePut } = await import('./storage');
        const { createBodyScan } = await import('./db');
        const { parseMeshData } = await import('./services/meshProcessor');
        
        // Generate unique file key
        const timestamp = Date.now();
        const fileKey = `scans/${ctx.user.id}/${timestamp}-${input.fileName}`;
        
        // Upload to S3
        const { url } = await storagePut(
          fileKey,
          Buffer.from(input.fileContent, 'base64'),
          `model/${input.fileFormat}`
        );
        
        // Parse mesh data
        const meshData = parseMeshData(input.fileContent, input.fileFormat);
        
        // Save to database
        const scanId = await createBodyScan({
          userId: ctx.user.id,
          fileKey,
          fileUrl: url,
          fileName: input.fileName,
          fileFormat: input.fileFormat,
          fileSize: input.fileSize,
          scanDate: input.scanDate,
          vertexCount: meshData.vertexCount,
          meshVolume: Math.round(meshData.volume * 1000),
          surfaceArea: Math.round(meshData.surfaceArea * 1000),
        });
        
        return { scanId, fileUrl: url };
      }),
    getById: protectedProcedure
      .input(z.object({ scanId: z.number() }))
      .query(async ({ ctx, input }) => {
        const { getBodyScanById } = await import('./db');
        const scan = await getBodyScanById(input.scanId);
        
        if (!scan || scan.userId !== ctx.user.id) {
          throw new Error('Scan not found or access denied');
        }
        
        return scan;
      }),
  }),

  comparisons: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const { getUserComparisons } = await import('./db');
      return getUserComparisons(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        baselineScanId: z.number(),
        comparisonScanId: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { getBodyScanById, createScanComparison, updateScanComparison, createBodyRegionMetrics, getUserProfile } = await import('./db');
        const { compareMeshes, parseMeshData } = await import('./services/meshProcessor');
        
        // Fetch both scans
        const baselineScan = await getBodyScanById(input.baselineScanId);
        const comparisonScan = await getBodyScanById(input.comparisonScanId);
        
        if (!baselineScan || !comparisonScan) {
          throw new Error('Scans not found');
        }
        
        if (baselineScan.userId !== ctx.user.id || comparisonScan.userId !== ctx.user.id) {
          throw new Error('Access denied');
        }
        
        // Create comparison record
        const comparisonId = await createScanComparison({
          userId: ctx.user.id,
          baselineScanId: input.baselineScanId,
          comparisonScanId: input.comparisonScanId,
          analysisComplete: 0,
        });
        
        // Fetch mesh files and parse
        // Note: In production, you'd fetch from S3 using fileUrl
        // For now, we'll simulate with stored data
        const userProfile = await getUserProfile(ctx.user.id);
        
        // This is a placeholder - in production, fetch actual file content from S3
        const baselineMeshData = { vertices: [], faces: [], vertexCount: 0, volume: 0, surfaceArea: 0 };
        const comparisonMeshData = { vertices: [], faces: [], vertexCount: 0, volume: 0, surfaceArea: 0 };
        
        // Perform comparison
        const profileData = userProfile ? {
          height: userProfile.height ?? undefined,
          weight: userProfile.weight ?? undefined,
          age: userProfile.age ?? undefined,
          gender: userProfile.gender ?? undefined,
        } : {};
        const result = compareMeshes(baselineMeshData, comparisonMeshData, profileData);
        
        // Update comparison with results
        await updateScanComparison(comparisonId, {
          overallVolumeChange: result.overallVolumeChange,
          bodyFatPercentage: result.bodyFatPercentage,
          muscleMassChange: result.muscleMassChange,
          fatMassChange: result.fatMassChange,
          colorMapData: JSON.stringify(result.colorMapData),
          analysisComplete: 1,
        });
        
        // Save region metrics
        const regionMetrics = result.regions.map(region => ({
          comparisonId,
          region: region.name as any,
          volumeChange: region.volumeChange,
          changePercentage: region.changePercentage,
          changeType: region.changeType,
          vertexCount: region.vertexIndices.length,
          avgMagnitude: Math.abs(region.volumeChange),
        }));
        
        await createBodyRegionMetrics(regionMetrics);
        
        return { comparisonId };
      }),
    getById: protectedProcedure
      .input(z.object({ comparisonId: z.number() }))
      .query(async ({ ctx, input }) => {
        const { getComparisonById, getRegionMetricsByComparison } = await import('./db');
        
        const comparison = await getComparisonById(input.comparisonId);
        if (!comparison || comparison.userId !== ctx.user.id) {
          throw new Error('Comparison not found or access denied');
        }
        
        const regions = await getRegionMetricsByComparison(input.comparisonId);
        
        return {
          ...comparison,
          regions,
          colorMapData: comparison.colorMapData ? JSON.parse(comparison.colorMapData) : [],
        };
      }),
  }),

  ai: router({
    getMealPlans: protectedProcedure.query(async ({ ctx }) => {
      const { getUserMealPlans } = await import('./db');
      return getUserMealPlans(ctx.user.id);
    }),
    getExercises: protectedProcedure
      .input(z.object({ comparisonId: z.number() }))
      .query(async ({ ctx, input }) => {
        const { getExerciseRecommendationsByComparison } = await import('./db');
        return getExerciseRecommendationsByComparison(input.comparisonId);
      }),
    generateMealPlan: protectedProcedure
      .input(z.object({
        comparisonId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { getUserProfile, getComparisonById, createMealPlan } = await import('./db');
        const { generateMealPlan } = await import('./services/aiService');
        
        const profile = await getUserProfile(ctx.user.id);
        if (!profile) {
          throw new Error('User profile not found');
        }
        
        let comparison;
        if (input.comparisonId) {
          comparison = await getComparisonById(input.comparisonId);
        }
        
        // Calculate daily calories based on profile
        const bmr = profile.weight && profile.height && profile.age
          ? calculateBMR(profile.weight, profile.height, profile.age, profile.gender ?? 'male')
          : 2000;
        
        const activityMultiplier = {
          sedentary: 1.2,
          light: 1.375,
          moderate: 1.55,
          active: 1.725,
          very_active: 1.9,
        }[profile.activityLevel ?? 'moderate'];
        
        const dailyCalories = Math.round(bmr * activityMultiplier);
        
        const mealPlanData = await generateMealPlan({
          fitnessGoal: profile.fitnessGoal ?? 'maintaining',
          dailyCalories,
          bodyFatPercentage: comparison?.bodyFatPercentage ?? undefined,
          muscleMassChange: comparison?.muscleMassChange ?? undefined,
          fatMassChange: comparison?.fatMassChange ?? undefined,
        });
        
        const planId = await createMealPlan({
          userId: ctx.user.id,
          comparisonId: input.comparisonId,
          weekStartDate: new Date(),
          dailyCalories,
          proteinGrams: Math.round(mealPlanData.macros.protein),
          carbsGrams: Math.round(mealPlanData.macros.carbs),
          fatsGrams: Math.round(mealPlanData.macros.fats),
          planData: JSON.stringify(mealPlanData),
        });
        
        return { planId, ...mealPlanData };
      }),
    
    generateExercises: protectedProcedure
      .input(z.object({
        comparisonId: z.number(),
        injuries: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { getUserProfile, getComparisonById, getRegionMetricsByComparison, createExerciseRecommendations } = await import('./db');
        const { generateExerciseRecommendations } = await import('./services/aiService');
        
        const profile = await getUserProfile(ctx.user.id);
        const comparison = await getComparisonById(input.comparisonId);
        const regions = await getRegionMetricsByComparison(input.comparisonId);
        
        if (!comparison || comparison.userId !== ctx.user.id) {
          throw new Error('Comparison not found');
        }
        
        const exercises = await generateExerciseRecommendations({
          regions: regions.map(r => ({
            name: r.region,
            changeType: r.changeType ?? 'stable',
            volumeChange: r.volumeChange ?? 0,
          })),
          fitnessGoal: profile?.fitnessGoal ?? 'maintaining',
          activityLevel: profile?.activityLevel ?? 'moderate',
          injuries: input.injuries,
        });
        
        const exerciseRecords = exercises.map((ex: any) => ({
          userId: ctx.user.id,
          comparisonId: input.comparisonId,
          targetRegion: ex.targetRegion,
          exerciseName: ex.name,
          sets: ex.sets,
          reps: ex.reps,
          intensity: ex.intensity,
          description: `${ex.description}\n\nModifications: ${ex.modifications}`,
        }));
        
        await createExerciseRecommendations(exerciseRecords);
        
        return exercises;
      }),
    
    chat: protectedProcedure
      .input(z.object({
        message: z.string(),
        injuries: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { getUserProfile, getUserComparisons, getUserChatHistory, createChatMessage } = await import('./db');
        const { chatWithAI } = await import('./services/aiService');
        
        // Get user context
        const profile = await getUserProfile(ctx.user.id);
        const comparisons = await getUserComparisons(ctx.user.id);
        const recentComparison = comparisons[0];
        
        // Get chat history
        const history = await getUserChatHistory(ctx.user.id, 20);
        const chatHistory = history.reverse().map(msg => ({
          role: msg.role as 'user' | 'assistant',
          content: msg.content,
        }));
        
        // Save user message
        await createChatMessage({
          userId: ctx.user.id,
          role: 'user',
          content: input.message,
        });
        
        // Get AI response
        const response = await chatWithAI({
          message: input.message,
          userContext: {
            fitnessGoal: profile?.fitnessGoal ?? undefined,
            recentComparison: recentComparison ? {
              bodyFatPercentage: recentComparison.bodyFatPercentage ?? undefined,
              muscleMassChange: recentComparison.muscleMassChange ?? undefined,
              fatMassChange: recentComparison.fatMassChange ?? undefined,
            } : undefined,
            injuries: input.injuries,
          },
          chatHistory,
        });
        
        // Save assistant message
        await createChatMessage({
          userId: ctx.user.id,
          role: 'assistant',
          content: response.message,
        });
        
        return response;
      }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;

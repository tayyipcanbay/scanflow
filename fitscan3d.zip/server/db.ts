import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  userProfiles,
  bodyScans,
  scanComparisons,
  bodyRegionMetrics,
  mealPlans,
  exerciseRecommendations,
  chatMessages,
  InsertUserProfile,
  InsertBodyScan,
  InsertScanComparison,
  InsertBodyRegionMetric,
  InsertMealPlan,
  InsertExerciseRecommendation,
  InsertChatMessage
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// User Profile Operations
export async function getUserProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrUpdateUserProfile(profile: InsertUserProfile) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getUserProfile(profile.userId);
  
  if (existing) {
    await db.update(userProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(userProfiles.userId, profile.userId));
    return getUserProfile(profile.userId);
  } else {
    await db.insert(userProfiles).values(profile);
    return getUserProfile(profile.userId);
  }
}

// Body Scan Operations
export async function createBodyScan(scan: InsertBodyScan) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(bodyScans).values(scan);
  const inserted = await db.select().from(bodyScans)
    .where(eq(bodyScans.userId, scan.userId))
    .orderBy(desc(bodyScans.createdAt))
    .limit(1);
  return inserted[0]?.id ?? 0;
}

export async function getUserScans(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(bodyScans)
    .where(eq(bodyScans.userId, userId))
    .orderBy(desc(bodyScans.scanDate));
}

export async function getBodyScanById(scanId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(bodyScans).where(eq(bodyScans.id, scanId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Scan Comparison Operations
export async function createScanComparison(comparison: InsertScanComparison) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(scanComparisons).values(comparison);
  const inserted = await db.select().from(scanComparisons)
    .where(eq(scanComparisons.userId, comparison.userId))
    .orderBy(desc(scanComparisons.createdAt))
    .limit(1);
  return inserted[0]?.id ?? 0;
}

export async function updateScanComparison(comparisonId: number, data: Partial<InsertScanComparison>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(scanComparisons)
    .set(data)
    .where(eq(scanComparisons.id, comparisonId));
}

export async function getUserComparisons(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(scanComparisons)
    .where(eq(scanComparisons.userId, userId))
    .orderBy(desc(scanComparisons.createdAt));
}

export async function getComparisonById(comparisonId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select()
    .from(scanComparisons)
    .leftJoin(bodyScans, eq(scanComparisons.baselineScanId, bodyScans.id))
    .where(eq(scanComparisons.id, comparisonId))
    .limit(1);
    
  if (result.length === 0) return undefined;
  
  const comparison = result[0].scan_comparisons;
  const baselineScan = result[0].body_scans;
  
  // Get comparison scan separately
  const compScanResult = await db.select().from(bodyScans)
    .where(eq(bodyScans.id, comparison.comparisonScanId))
    .limit(1);
  const comparisonScan = compScanResult[0];
  
  if (!baselineScan || !comparisonScan) return undefined;
  
  return {
    ...comparison,
    baselineScan,
    comparisonScan,
  };
}

// Body Region Metrics Operations
export async function createBodyRegionMetrics(metrics: InsertBodyRegionMetric[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (metrics.length === 0) return;
  await db.insert(bodyRegionMetrics).values(metrics);
}

export async function getRegionMetricsByComparison(comparisonId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(bodyRegionMetrics)
    .where(eq(bodyRegionMetrics.comparisonId, comparisonId));
}

// Meal Plan Operations
export async function createMealPlan(plan: InsertMealPlan) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(mealPlans).values(plan);
  const inserted = await db.select().from(mealPlans)
    .where(eq(mealPlans.userId, plan.userId))
    .orderBy(desc(mealPlans.createdAt))
    .limit(1);
  return inserted[0]?.id ?? 0;
}

export async function getUserMealPlans(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(mealPlans)
    .where(eq(mealPlans.userId, userId))
    .orderBy(desc(mealPlans.weekStartDate));
}

export async function getLatestMealPlan(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(mealPlans)
    .where(eq(mealPlans.userId, userId))
    .orderBy(desc(mealPlans.weekStartDate))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Exercise Recommendation Operations
export async function createExerciseRecommendations(recommendations: InsertExerciseRecommendation[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (recommendations.length === 0) return;
  await db.insert(exerciseRecommendations).values(recommendations);
}

export async function getUserExerciseRecommendations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(exerciseRecommendations)
    .where(eq(exerciseRecommendations.userId, userId))
    .orderBy(desc(exerciseRecommendations.createdAt));
}

export async function getExerciseRecommendationsByComparison(comparisonId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(exerciseRecommendations)
    .where(eq(exerciseRecommendations.comparisonId, comparisonId))
    .orderBy(desc(exerciseRecommendations.createdAt));
}

// Chat Message Operations
export async function createChatMessage(message: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(chatMessages).values(message);
  const inserted = await db.select().from(chatMessages)
    .where(eq(chatMessages.userId, message.userId))
    .orderBy(desc(chatMessages.createdAt))
    .limit(1);
  return inserted[0]?.id ?? 0;
}

export async function getUserChatHistory(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(chatMessages)
    .where(eq(chatMessages.userId, userId))
    .orderBy(desc(chatMessages.createdAt))
    .limit(limit);
}

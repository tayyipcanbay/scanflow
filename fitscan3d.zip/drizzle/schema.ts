import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User profiles with fitness goals and body metrics
 */
export const userProfiles = mysqlTable("user_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  height: int("height"),
  weight: int("weight"),
  age: int("age"),
  gender: mysqlEnum("gender", ["male", "female", "other"]),
  fitnessGoal: mysqlEnum("fitness_goal", ["bulking", "cutting", "maintaining", "recomp"]).default("maintaining"),
  activityLevel: mysqlEnum("activity_level", ["sedentary", "light", "moderate", "active", "very_active"]).default("moderate"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;

/**
 * Body scans - stores 3D mesh file references and metadata
 */
export const bodyScans = mysqlTable("body_scans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  fileKey: varchar("file_key", { length: 512 }).notNull(),
  fileUrl: text("file_url").notNull(),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  fileFormat: mysqlEnum("file_format", ["obj", "glb", "fbx"]).notNull(),
  fileSize: int("file_size"),
  scanDate: timestamp("scan_date").notNull(),
  vertexCount: int("vertex_count"),
  meshVolume: int("mesh_volume"),
  surfaceArea: int("surface_area"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type BodyScan = typeof bodyScans.$inferSelect;
export type InsertBodyScan = typeof bodyScans.$inferInsert;

/**
 * Scan comparisons - pairs of baseline and comparison scans with analysis results
 */
export const scanComparisons = mysqlTable("scan_comparisons", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  baselineScanId: int("baseline_scan_id").notNull().references(() => bodyScans.id, { onDelete: "cascade" }),
  comparisonScanId: int("comparison_scan_id").notNull().references(() => bodyScans.id, { onDelete: "cascade" }),
  overallVolumeChange: int("overall_volume_change"),
  bodyFatPercentage: int("body_fat_percentage"),
  muscleMassChange: int("muscle_mass_change"),
  fatMassChange: int("fat_mass_change"),
  colorMapData: text("color_map_data"),
  analysisComplete: int("analysis_complete").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ScanComparison = typeof scanComparisons.$inferSelect;
export type InsertScanComparison = typeof scanComparisons.$inferInsert;

/**
 * Body region metrics - detailed changes per body region
 */
export const bodyRegionMetrics = mysqlTable("body_region_metrics", {
  id: int("id").autoincrement().primaryKey(),
  comparisonId: int("comparison_id").notNull().references(() => scanComparisons.id, { onDelete: "cascade" }),
  region: mysqlEnum("region", ["waist", "chest", "arms", "thighs", "hips", "shoulders", "calves", "other"]).notNull(),
  volumeChange: int("volume_change"),
  changePercentage: int("change_percentage"),
  changeType: mysqlEnum("change_type", ["increase", "decrease", "stable"]),
  vertexCount: int("vertex_count"),
  avgMagnitude: int("avg_magnitude"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type BodyRegionMetric = typeof bodyRegionMetrics.$inferSelect;
export type InsertBodyRegionMetric = typeof bodyRegionMetrics.$inferInsert;

/**
 * Meal plans - AI-generated weekly meal plans
 */
export const mealPlans = mysqlTable("meal_plans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  comparisonId: int("comparison_id").references(() => scanComparisons.id, { onDelete: "set null" }),
  weekStartDate: timestamp("week_start_date").notNull(),
  dailyCalories: int("daily_calories"),
  proteinGrams: int("protein_grams"),
  carbsGrams: int("carbs_grams"),
  fatsGrams: int("fats_grams"),
  planData: text("plan_data").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlan = typeof mealPlans.$inferInsert;

/**
 * Exercise recommendations - AI-generated targeted workouts
 */
export const exerciseRecommendations = mysqlTable("exercise_recommendations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  comparisonId: int("comparison_id").references(() => scanComparisons.id, { onDelete: "set null" }),
  targetRegion: mysqlEnum("target_region", ["waist", "chest", "arms", "thighs", "hips", "shoulders", "calves", "back", "full_body"]),
  exerciseName: varchar("exercise_name", { length: 255 }).notNull(),
  sets: int("sets"),
  reps: varchar("reps", { length: 50 }),
  duration: varchar("duration", { length: 50 }),
  intensity: mysqlEnum("intensity", ["low", "moderate", "high"]),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ExerciseRecommendation = typeof exerciseRecommendations.$inferSelect;
export type InsertExerciseRecommendation = typeof exerciseRecommendations.$inferInsert;

/**
 * Chat messages - AI chatbot conversation history
 */
export const chatMessages = mysqlTable("chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;
CREATE TABLE `body_region_metrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`comparison_id` int NOT NULL,
	`region` enum('waist','chest','arms','thighs','hips','shoulders','calves','other') NOT NULL,
	`volume_change` int,
	`change_percentage` int,
	`change_type` enum('increase','decrease','stable'),
	`vertex_count` int,
	`avg_magnitude` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `body_region_metrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `body_scans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`file_key` varchar(512) NOT NULL,
	`file_url` text NOT NULL,
	`file_name` varchar(255) NOT NULL,
	`file_format` enum('obj','glb','fbx') NOT NULL,
	`file_size` int,
	`scan_date` timestamp NOT NULL,
	`vertex_count` int,
	`mesh_volume` int,
	`surface_area` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `body_scans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chat_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`role` enum('user','assistant','system') NOT NULL,
	`content` text NOT NULL,
	`metadata` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `exercise_recommendations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`comparison_id` int,
	`target_region` enum('waist','chest','arms','thighs','hips','shoulders','calves','full_body'),
	`exercise_name` varchar(255) NOT NULL,
	`sets` int,
	`reps` varchar(50),
	`duration` varchar(50),
	`intensity` enum('low','moderate','high'),
	`description` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `exercise_recommendations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `meal_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`comparison_id` int,
	`week_start_date` timestamp NOT NULL,
	`daily_calories` int,
	`protein_grams` int,
	`carbs_grams` int,
	`fats_grams` int,
	`plan_data` text NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `meal_plans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `scan_comparisons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`baseline_scan_id` int NOT NULL,
	`comparison_scan_id` int NOT NULL,
	`overall_volume_change` int,
	`body_fat_percentage` int,
	`muscle_mass_change` int,
	`fat_mass_change` int,
	`color_map_data` text,
	`analysis_complete` int DEFAULT 0,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `scan_comparisons_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`height` int,
	`weight` int,
	`age` int,
	`gender` enum('male','female','other'),
	`fitness_goal` enum('bulking','cutting','maintaining','recomp') DEFAULT 'maintaining',
	`activity_level` enum('sedentary','light','moderate','active','very_active') DEFAULT 'moderate',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_profiles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `body_region_metrics` ADD CONSTRAINT `body_region_metrics_comparison_id_scan_comparisons_id_fk` FOREIGN KEY (`comparison_id`) REFERENCES `scan_comparisons`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `body_scans` ADD CONSTRAINT `body_scans_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `chat_messages` ADD CONSTRAINT `chat_messages_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `exercise_recommendations` ADD CONSTRAINT `exercise_recommendations_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `exercise_recommendations` ADD CONSTRAINT `exercise_recommendations_comparison_id_scan_comparisons_id_fk` FOREIGN KEY (`comparison_id`) REFERENCES `scan_comparisons`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `meal_plans` ADD CONSTRAINT `meal_plans_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `meal_plans` ADD CONSTRAINT `meal_plans_comparison_id_scan_comparisons_id_fk` FOREIGN KEY (`comparison_id`) REFERENCES `scan_comparisons`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `scan_comparisons` ADD CONSTRAINT `scan_comparisons_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `scan_comparisons` ADD CONSTRAINT `scan_comparisons_baseline_scan_id_body_scans_id_fk` FOREIGN KEY (`baseline_scan_id`) REFERENCES `body_scans`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `scan_comparisons` ADD CONSTRAINT `scan_comparisons_comparison_scan_id_body_scans_id_fk` FOREIGN KEY (`comparison_scan_id`) REFERENCES `body_scans`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_profiles` ADD CONSTRAINT `user_profiles_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;